import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  Banknote,
  Leaf,
  MapPin,
  Minus,
  Plus,
  QrCode,
  ShoppingBag,
  Store,
  Truck,
  Upload,
  X,
} from "lucide-react";
import { baht, buildPromptPayPayload, haversineKm, quoteOrder } from "@/lib/pos/calc";
import { usePos } from "@/lib/pos/store";
import type { Fulfillment, PayMethod } from "@/lib/pos/types";

export function BootScreen() {
  return (
    <main className="grid min-h-screen place-items-center px-6">
      <div className="text-center">
        <div className="mx-auto mb-4 grid size-14 place-items-center rounded-2xl bg-primary text-primary-fg">
          <Leaf className="size-7" aria-hidden="true" />
        </div>
        <h1 className="text-2xl font-semibold tracking-tight">ใบเขียว</h1>
        <p className="mt-1 text-sm text-muted">กำลังเปิดร้าน</p>
      </div>
    </main>
  );
}

function fileToSlip(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("อ่านไฟล์ไม่สำเร็จ"));
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const max = 1000;
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(String(reader.result));
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.72));
      };
      img.onerror = () => reject(new Error("ไฟล์รูปไม่ถูกต้อง"));
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

function PromptQr({ payload }: { payload: string }) {
  const [src, setSrc] = useState("");
  useEffect(() => {
    let dead = false;
    void import("qrcode").then((QR) => {
      void QR.toDataURL(payload, {
        margin: 1,
        width: 360,
        errorCorrectionLevel: "M",
        color: { dark: "#06281c", light: "#ffffff" },
      }).then((url) => {
        if (!dead) setSrc(url);
      });
    });
    return () => {
      dead = true;
    };
  }, [payload]);
  if (!src) return <div className="grid h-56 w-56 place-items-center text-sm text-muted">กำลังสร้าง QR</div>;
  return <img src={src} alt="คิวอาร์พร้อมเพย์ตามยอดสั่งซื้อ" className="h-56 w-56" />;
}

export function Storefront() {
  const products = usePos((s) => s.products);
  const cart = usePos((s) => s.cart);
  const session = usePos((s) => s.session);
  const settings = usePos((s) => s.settings);
  const promos = usePos((s) => s.promos);
  const customers = usePos((s) => s.customers);
  const orders = usePos((s) => s.orders);
  const setQty = usePos((s) => s.setQty);
  const setSession = usePos((s) => s.setSession);
  const placeOrder = usePos((s) => s.placeOrder);

  const [age, setAge] = useState<"wait" | "ask" | "yes" | "no">("wait");
  const [cat, setCat] = useState("ทั้งหมด");
  const [view, setView] = useState<"shop" | "checkout" | "done">("shop");
  const [loginOpen, setLoginOpen] = useState(false);
  const [draftName, setDraftName] = useState("");
  const [fulfillment, setFulfillment] = useState<Fulfillment>("DELIVERY");
  const [address, setAddress] = useState("");
  const [note, setNote] = useState("");
  const [lat, setLat] = useState("");
  const [lng, setLng] = useState("");
  const [geoMsg, setGeoMsg] = useState("");
  const [pay, setPay] = useState<PayMethod>("CASH");
  const [slip, setSlip] = useState("");
  const [promoCode, setPromoCode] = useState("");
  const [points, setPoints] = useState(0);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [doneId, setDoneId] = useState("");

  useEffect(() => {
    setAge(localStorage.getItem("bai-khiao-age") === "yes" ? "yes" : "ask");
  }, []);

  const active = products.filter((p) => p.status === "ACTIVE");
  const cats = ["ทั้งหมด", ...Array.from(new Set(active.map((p) => p.recipeType)))];
  const shown = active.filter((p) => cat === "ทั้งหมด" || p.recipeType === cat);
  const lines = cart
    .map((line) => ({ ...line, product: products.find((p) => p.id === line.productId) }))
    .filter((line) => line.product && line.qty > 0);
  const count = lines.reduce((sum, line) => sum + line.qty, 0);
  const subTotal = lines.reduce((sum, line) => sum + line.product!.price * line.qty, 0);
  const customer = customers.find((c) => c.lineUserId === session?.lineUserId);
  const balance = customer?.points ?? 0;
  const latN = Number(lat);
  const lngN = Number(lng);
  const hasGeo = lat.trim() !== "" && lng.trim() !== "" && Number.isFinite(latN) && Number.isFinite(lngN);
  const distance = hasGeo ? haversineKm(settings.shopLat, settings.shopLng, latN, lngN) : 0;
  const code = promoCode.trim().toUpperCase();
  const promo = code ? promos.find((p) => p.code.toUpperCase() === code) ?? null : null;
  const quote = quoteOrder({
    subTotal,
    promo,
    pointsRequested: points,
    pointsBalance: balance,
    pointValue: settings.pointValue,
    pointsRate: settings.pointsRate,
    distanceKm: distance,
    feeBase: settings.feeBase,
    feePerKm: settings.feePerKm,
    fulfillment,
  });
  const promoHint = !code
    ? ""
    : !promo || !promo.active
      ? "ไม่พบโค้ดนี้"
      : subTotal < promo.minSpend
        ? `ใช้ได้เมื่อซื้อครบ ${baht(promo.minSpend)}`
        : `ใช้โค้ด ${promo.code} แล้ว`;
  const maxPoints = Math.min(balance, Math.floor(Math.max(0, subTotal - quote.promoOff) / Math.max(0.01, settings.pointValue)));
  const payload = useMemo(
    () => buildPromptPayPayload(settings.promptPayId, quote.total),
    [settings.promptPayId, quote.total],
  );
  const done = orders.find((o) => o.orderId === doneId);

  function acceptAge() {
    localStorage.setItem("bai-khiao-age", "yes");
    setAge("yes");
  }

  function login() {
    const name = draftName.trim();
    if (!name) {
      setError("ใส่ชื่อที่ต้องการให้ร้านเรียก");
      return;
    }
    const lineUserId = session?.lineUserId || `LOCAL-${Math.random().toString(36).slice(2, 10).toUpperCase()}`;
    setSession({ lineUserId, name, pictureUrl: "" });
    setLoginOpen(false);
    setError("");
  }

  async function locate() {
    setGeoMsg("กำลังขอพิกัด…");
    try {
      const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
        if (!navigator.geolocation) {
          reject(new Error("อุปกรณ์นี้ไม่เปิดพิกัด"));
          return;
        }
        navigator.geolocation.getCurrentPosition(resolve, () => reject(new Error("ไม่ได้รับอนุญาตให้ใช้พิกัด")), {
          enableHighAccuracy: true,
          timeout: 12000,
          maximumAge: 15000,
        });
      });
      setLat(pos.coords.latitude.toFixed(6));
      setLng(pos.coords.longitude.toFixed(6));
      setGeoMsg("ใช้พิกัดปัจจุบันแล้ว");
    } catch (err) {
      setGeoMsg(err instanceof Error ? err.message : "ดึงพิกัดไม่สำเร็จ");
    }
  }

  function useSamplePin() {
    setLat((settings.shopLat + 0.0108).toFixed(6));
    setLng((settings.shopLng + 0.0042).toFixed(6));
    setGeoMsg("ใส่พิกัดตัวอย่างห่างจากร้านประมาณ 1.3 กม.");
  }

  async function onSlip(file: File | undefined) {
    if (!file) return;
    setError("");
    try {
      setSlip(await fileToSlip(file));
    } catch (err) {
      setError(err instanceof Error ? err.message : "อัปโหลดสลิปไม่สำเร็จ");
    }
  }

  function submit() {
    setBusy(true);
    setError("");
    const result = placeOrder({
      fulfillment,
      address,
      lat: hasGeo ? latN : null,
      lng: hasGeo ? lngN : null,
      paymentMethod: pay,
      slipDataUrl: slip,
      note,
      promoCode: code,
      pointsRequested: points,
    });
    setBusy(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setDoneId(result.orderId);
    setSlip("");
    setPoints(0);
    setPromoCode("");
    setView("done");
  }

  if (age === "wait") return <BootScreen />;

  if (age !== "yes") {
    return (
      <main className="grid min-h-screen place-items-center px-5">
        <section className="glass w-full max-w-md rounded-3xl p-6">
          <div className="mb-5 grid size-12 place-items-center rounded-2xl bg-primary text-primary-fg">
            <Leaf className="size-6" aria-hidden="true" />
          </div>
          <p className="text-sm text-primary">จำหน่ายเฉพาะผู้มีอายุ 18 ปีขึ้นไป</p>
          <h1 className="mt-1 text-3xl font-semibold tracking-tight">{settings.shopName}</h1>
          <p className="mt-3 text-sm leading-6 text-muted">
            สินค้าสมุนไพรตามกฎหมายไทย ไม่มีสรรพคุณรักษาโรค ยืนยันอายุก่อนเข้าหน้าร้าน
          </p>
          {age === "no" ? (
            <p className="mt-4 rounded-2xl bg-elevated px-4 py-3 text-sm text-danger" role="alert">
              ขออภัย ร้านนี้ให้บริการเฉพาะผู้มีอายุ 18 ปีบริบูรณ์
            </p>
          ) : null}
          <div className="mt-6 grid gap-3">
            <button type="button" onClick={acceptAge} className="min-h-11 rounded-2xl bg-primary px-4 font-medium text-primary-fg">
              ฉันอายุ 18 ปีขึ้นไป
            </button>
            <button type="button" onClick={() => setAge("no")} className="min-h-11 rounded-2xl bg-elevated px-4 text-muted">
              ยังไม่ถึง 18 ปี
            </button>
          </div>
        </section>
      </main>
    );
  }

  return (
    <div className="mx-auto min-h-screen max-w-lg">
      <header className="glass sticky top-0 z-20 px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="grid size-11 shrink-0 place-items-center rounded-2xl bg-primary text-primary-fg">
            <Leaf className="size-5" aria-hidden="true" />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-lg font-semibold leading-tight">{settings.shopName}</h1>
            <a href={`tel:${settings.shopPhone}`} className="text-sm text-muted">{settings.shopPhone}</a>
          </div>
          <button
            type="button"
            onClick={() => (session ? setSession(null) : setLoginOpen(true))}
            className="min-h-11 rounded-2xl bg-elevated px-3 text-left"
          >
            <span className="block text-xs text-muted">{session ? "แต้มสะสม" : "เข้าสู่ระบบ"}</span>
            <span className="block text-sm font-medium text-primary">{session ? `${balance} แต้ม` : "ลูกค้า"}</span>
          </button>
        </div>
      </header>

      <main className="px-4 pb-28 pt-4">
        <p className="mb-4 text-sm leading-6 text-muted">
          สั่งรับที่ร้านหรือให้ส่งถึงที่ ค่าส่งคิดจากระยะจริง · ได้ 1 แต้มทุก {settings.pointsRate} บาท
        </p>
        <div className="no-scrollbar -mx-4 mb-4 flex gap-2 overflow-x-auto px-4">
          {cats.map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => setCat(item)}
              className={`min-h-11 shrink-0 rounded-full px-4 text-sm ${item === cat ? "bg-primary text-primary-fg" : "bg-elevated text-muted"}`}
            >
              {item}
            </button>
          ))}
        </div>
        <ul className="grid grid-cols-2 gap-3">
          {shown.map((product) => {
            const qty = cart.find((c) => c.productId === product.id)?.qty ?? 0;
            const soldOut = product.stock <= 0;
            return (
              <li key={product.id} className="overflow-hidden rounded-3xl border border-line bg-surface">
                <div className="relative aspect-square bg-elevated">
                  {product.imageUrl ? (
                    <img src={product.imageUrl} alt={product.name} className="h-full w-full object-cover" />
                  ) : (
                    <div className="grid h-full place-items-center text-primary">
                      <Leaf className="size-8" aria-hidden="true" />
                    </div>
                  )}
                  <span className="absolute left-2 top-2 rounded-full bg-bg/80 px-2 py-1 text-xs">{product.recipeType}</span>
                </div>
                <div className="space-y-2 p-3">
                  <h2 className="line-clamp-2 min-h-11 text-sm font-medium leading-5">{product.name}</h2>
                  <div className="flex items-end justify-between gap-2">
                    <p className="text-base font-semibold text-primary">{baht(product.price)}</p>
                    <p className={`text-xs ${product.stock <= 5 ? "text-danger" : "text-muted"}`}>
                      {soldOut ? "หมด" : `เหลือ ${product.stock}`}
                    </p>
                  </div>
                  {qty > 0 ? (
                    <div className="flex items-center justify-between rounded-2xl bg-elevated p-1">
                      <button type="button" aria-label="ลดจำนวน" onClick={() => setQty(product.id, qty - 1)} className="grid size-11 place-items-center rounded-xl">
                        <Minus className="size-4" />
                      </button>
                      <span className="text-sm font-medium">{qty}</span>
                      <button type="button" aria-label="เพิ่มจำนวน" disabled={qty >= product.stock} onClick={() => setQty(product.id, qty + 1)} className="grid size-11 place-items-center rounded-xl disabled:opacity-40">
                        <Plus className="size-4" />
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      disabled={soldOut}
                      onClick={() => setQty(product.id, 1)}
                      className="min-h-11 w-full rounded-2xl bg-primary text-sm font-medium text-primary-fg disabled:bg-elevated disabled:text-muted"
                    >
                      {soldOut ? "สินค้าหมด" : "ใส่ตะกร้า"}
                    </button>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
        <p className="mt-8 text-center text-xs leading-5 text-muted">
          จำหน่ายเฉพาะอายุ 18+ · ใน LINE จะล็อกอินโปรไฟล์จริงผ่าน LIFF
          <br />
          <Link to="/admin" className="text-primary">หลังบ้าน</Link>
        </p>
      </main>

      {count > 0 && view === "shop" ? (
        <div className="fixed inset-x-0 bottom-0 z-20 mx-auto max-w-lg px-4 safe-b">
          <button
            type="button"
            onClick={() => {
              setError("");
              if (!session) {
                setLoginOpen(true);
                return;
              }
              setView("checkout");
            }}
            className="mb-3 flex min-h-14 w-full items-center justify-between rounded-3xl bg-primary px-4 text-primary-fg"
          >
            <span className="flex items-center gap-2 font-medium"><ShoppingBag className="size-5" /> {count} ชิ้น</span>
            <span className="font-semibold">{baht(subTotal)} · สั่งเลย</span>
          </button>
        </div>
      ) : null}

      {loginOpen ? (
        <div className="fixed inset-0 z-40 grid place-items-end bg-bg/70 px-4 pb-6 sm:place-items-center">
          <section className="glass w-full max-w-md rounded-3xl p-5">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-xl font-semibold">เข้าสู่ระบบลูกค้า</h2>
              <button type="button" aria-label="ปิด" onClick={() => setLoginOpen(false)} className="grid size-11 place-items-center"><X /></button>
            </div>
            <p className="text-sm leading-6 text-muted">พรีวิวนี้จำลองโปรไฟล์ LINE ชื่อและแต้มจะผูกกับลูกค้าคนนี้จนกว่าจะสลับ</p>
            <label className="mt-4 block text-sm text-muted" htmlFor="cust-name">ชื่อที่ให้ร้านเรียก</label>
            <input id="cust-name" value={draftName} onChange={(e) => setDraftName(e.target.value)} className="mt-1 min-h-11 w-full rounded-2xl border border-line bg-elevated px-3 text-base" placeholder="เช่น คุณเมย์" />
            {error ? <p className="mt-3 text-sm text-danger" role="alert">{error}</p> : null}
            <button type="button" onClick={login} className="mt-4 min-h-11 w-full rounded-2xl bg-primary font-medium text-primary-fg">เริ่มสั่งซื้อ</button>
          </section>
        </div>
      ) : null}

      {view === "checkout" ? (
        <section className="fixed inset-0 z-30 overflow-y-auto bg-bg">
          <div className="mx-auto min-h-full max-w-lg px-4 pb-10 pt-4">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-xl font-semibold">ยืนยันออเดอร์</h2>
              <button type="button" onClick={() => setView("shop")} className="min-h-11 rounded-2xl px-3 text-sm text-muted">กลับร้าน</button>
            </div>
            <ul className="space-y-2">
              {lines.map((line) => (
                <li key={line.productId} className="flex items-center justify-between gap-3 rounded-2xl bg-surface px-3 py-2">
                  <div>
                    <p className="text-sm font-medium">{line.product!.name}</p>
                    <p className="text-xs text-muted">{baht(line.product!.price)} × {line.qty}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <button type="button" aria-label="ลด" onClick={() => setQty(line.productId, line.qty - 1)} className="grid size-11 place-items-center rounded-xl bg-elevated"><Minus className="size-4" /></button>
                    <button type="button" aria-label="เพิ่ม" onClick={() => setQty(line.productId, line.qty + 1)} className="grid size-11 place-items-center rounded-xl bg-elevated"><Plus className="size-4" /></button>
                  </div>
                </li>
              ))}
            </ul>

            <div className="mt-4 grid grid-cols-2 gap-2">
              <button type="button" onClick={() => setFulfillment("DELIVERY")} className={`min-h-11 rounded-2xl text-sm ${fulfillment === "DELIVERY" ? "bg-primary text-primary-fg" : "bg-elevated text-muted"}`}>
                <Truck className="mx-auto mb-1 size-4" /> จัดส่ง
              </button>
              <button type="button" onClick={() => setFulfillment("PICKUP")} className={`min-h-11 rounded-2xl text-sm ${fulfillment === "PICKUP" ? "bg-primary text-primary-fg" : "bg-elevated text-muted"}`}>
                <Store className="mx-auto mb-1 size-4" /> รับที่ร้าน
              </button>
            </div>

            {fulfillment === "DELIVERY" ? (
              <div className="mt-4 space-y-3">
                <label className="block text-sm text-muted" htmlFor="addr">ที่อยู่จัดส่ง</label>
                <textarea id="addr" value={address} onChange={(e) => setAddress(e.target.value)} rows={3} className="w-full rounded-2xl border border-line bg-surface px-3 py-2 text-base" placeholder="บ้านเลขที่ ซอย ถนน แขวง เขต" />
                <div className="grid grid-cols-2 gap-2">
                  <button type="button" onClick={() => void locate()} className="min-h-11 rounded-2xl bg-elevated px-3 text-sm"><MapPin className="mr-1 inline size-4" />พิกัดปัจจุบัน</button>
                  <button type="button" onClick={useSamplePin} className="min-h-11 rounded-2xl bg-elevated px-3 text-sm">พิกัดใกล้ร้าน</button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input value={lat} onChange={(e) => setLat(e.target.value)} inputMode="decimal" aria-label="ละติจูด" placeholder="ละติจูด" className="min-h-11 rounded-2xl border border-line bg-surface px-3 text-base" />
                  <input value={lng} onChange={(e) => setLng(e.target.value)} inputMode="decimal" aria-label="ลองจิจูด" placeholder="ลองจิจูด" className="min-h-11 rounded-2xl border border-line bg-surface px-3 text-base" />
                </div>
                <p className="text-sm text-muted">
                  {geoMsg ? `${geoMsg} · ` : ""}
                  {hasGeo ? `ห่าง ${distance.toFixed(2)} กม. · ค่าส่ง ${baht(quote.delivery)}` : "ยังไม่มีพิกัด จึงยังไม่คิดค่าส่ง"}
                </p>
              </div>
            ) : (
              <p className="mt-3 text-sm text-muted">รับที่ร้าน ไม่มีค่าส่ง</p>
            )}

            <label className="mt-4 block text-sm text-muted" htmlFor="note">โน้ตถึงร้าน</label>
            <input id="note" value={note} onChange={(e) => setNote(e.target.value)} className="mt-1 min-h-11 w-full rounded-2xl border border-line bg-surface px-3 text-base" placeholder="โทรก่อนถึง / จุดสังเกต" />

            <div className="mt-4">
              <p className="text-sm text-muted">โค้ดส่วนลด</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {promos.filter((p) => p.active).map((p) => (
                  <button key={p.code} type="button" onClick={() => setPromoCode(p.code)} className="min-h-11 rounded-full bg-elevated px-3 text-sm">
                    {p.code}
                  </button>
                ))}
              </div>
              <input value={promoCode} onChange={(e) => setPromoCode(e.target.value.toUpperCase())} className="mt-2 min-h-11 w-full rounded-2xl border border-line bg-surface px-3 text-base uppercase" placeholder="ใส่โค้ด" />
              {promoHint ? <p className="mt-1 text-sm text-muted">{promoHint}</p> : null}
            </div>

            <div className="mt-4 rounded-3xl bg-surface p-4">
              <div className="flex items-center justify-between text-sm">
                <span>แต้มที่มี</span>
                <span className="font-medium text-primary">{balance} แต้ม</span>
              </div>
              <input type="range" min={0} max={Math.max(0, maxPoints)} value={Math.min(points, maxPoints)} onChange={(e) => setPoints(Number(e.target.value))} className="mt-3 w-full" aria-label="แต้มที่ใช้แลกส่วนลด" />
              <p className="text-sm text-muted">ใช้ {Math.min(points, maxPoints)} แต้ม = ลด {baht(quote.pointsOff)} · ออเดอร์นี้ได้เพิ่ม {quote.pointsEarned} แต้ม</p>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-2">
              <button type="button" onClick={() => setPay("CASH")} className={`min-h-11 rounded-2xl text-sm ${pay === "CASH" ? "bg-primary text-primary-fg" : "bg-elevated text-muted"}`}>
                <Banknote className="mx-auto mb-1 size-4" /> เงินสด
              </button>
              <button type="button" onClick={() => setPay("TRANSFER")} className={`min-h-11 rounded-2xl text-sm ${pay === "TRANSFER" ? "bg-primary text-primary-fg" : "bg-elevated text-muted"}`}>
                <QrCode className="mx-auto mb-1 size-4" /> โอนพร้อมเพย์
              </button>
            </div>

            {pay === "TRANSFER" ? (
              <div className="mt-4 rounded-3xl bg-fg p-4 text-bg">
                <div className="mx-auto w-fit rounded-2xl bg-fg p-2">
                  <PromptQr payload={payload} />
                </div>
                <p className="mt-2 text-center text-sm">สแกนจ่าย {baht(quote.total)} · {settings.promptPayId}</p>
                <p className="text-center text-xs opacity-70">คิวอาร์แบบไดนามิก ยอดถูกใส่ในโค้ดแล้ว</p>
                <label className="mt-3 flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-2xl bg-primary text-sm font-medium text-primary-fg">
                  <Upload className="size-4" /> {slip ? "เปลี่ยนสลิป" : "อัปโหลดสลิป"}
                  <input type="file" accept="image/*" className="sr-only" onChange={(e) => void onSlip(e.target.files?.[0])} />
                </label>
                {slip ? <img src={slip} alt="สลิปที่อัปโหลด" className="mx-auto mt-3 max-h-48 rounded-2xl" /> : null}
              </div>
            ) : null}

            <dl className="mt-4 space-y-1 text-sm">
              <div className="flex justify-between"><dt className="text-muted">สินค้า</dt><dd>{baht(subTotal)}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">ส่วนลด</dt><dd>-{baht(quote.discount)}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">ค่าส่ง</dt><dd>{baht(quote.delivery)}</dd></div>
              <div className="flex justify-between text-base font-semibold"><dt>ยอดสุทธิ</dt><dd className="text-primary">{baht(quote.total)}</dd></div>
            </dl>
            {error ? <p className="mt-3 text-sm text-danger" role="alert">{error}</p> : null}
            <button type="button" disabled={busy || count === 0} onClick={submit} className="mt-4 min-h-12 w-full rounded-2xl bg-primary font-medium text-primary-fg disabled:opacity-40">
              ยืนยันสั่งซื้อ
            </button>
          </div>
        </section>
      ) : null}

      {view === "done" && done ? (
        <section className="fixed inset-0 z-30 grid place-items-center overflow-y-auto bg-bg px-4">
          <div className="w-full max-w-md rounded-3xl bg-surface p-6 text-center">
            <div className="mx-auto mb-3 grid size-14 place-items-center rounded-2xl bg-primary text-primary-fg">
              <Leaf className="size-7" />
            </div>
            <h2 className="text-2xl font-semibold">รับออเดอร์แล้ว</h2>
            <p className="mt-1 text-sm text-muted">{done.orderId}</p>
            <p className="mt-4 text-3xl font-semibold text-primary">{baht(done.total)}</p>
            <p className="mt-2 text-sm text-muted">สถานะรอดำเนินการ · ได้ {done.pointsEarned} แต้ม · คงเหลือ {customers.find((c) => c.lineUserId === done.lineUserId)?.points ?? 0} แต้ม</p>
            <button type="button" onClick={() => setView("shop")} className="mt-6 min-h-11 w-full rounded-2xl bg-primary font-medium text-primary-fg">กลับไปเลือกสินค้า</button>
          </div>
        </section>
      ) : null}
    </div>
  );
}
