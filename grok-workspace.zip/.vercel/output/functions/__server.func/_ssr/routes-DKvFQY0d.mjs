import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Storefront, s as usePosReady, t as BootScreen } from "./ready-BfabTftk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DKvFQY0d.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	if (!usePosReady()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Storefront, {});
}
//#endregion
export { Home as component };
