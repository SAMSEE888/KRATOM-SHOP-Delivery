import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { haversineKm, quoteOrder } from "@/lib/pos/calc";
import type {
  CartLine,
  Customer,
  Fulfillment,
  Order,
  OrderItem,
  OrderStatus,
  PayMethod,
  Product,
  Promo,
  SessionUser,
  Settings,
  StockLog,
} from "@/lib/pos/types";

export const defaultSettings = (): Settings => ({
  shopName: "ใบเขียว",
  shopPhone: "02-000-0000",
  promptPayId: "0899999991",
  shopLat: 13.7563,
  shopLng: 100.5018,
  feeBase: 25,
  feePerKm: 8,
  pointsRate: 50,
  pointValue: 1,
  lineChannelToken: "",
  lineAdminUserId: "",
  adminPin: "2580",
});

export function seedProducts(): Product[] {
  return [
    { id: "P001", name: "ใบกระท่อมแดงอบแห้ง 100 กรัม", price: 180, recipeType: "ใบแห้ง", status: "ACTIVE", imageUrl: "/products/leaf-red.jpg", stock: 40 },
    { id: "P002", name: "ผงกระท่อมคัดใบ 50 กรัม", price: 220, recipeType: "ผง", status: "ACTIVE", imageUrl: "/products/powder.jpg", stock: 30 },
    { id: "P003", name: "ชาชงใบเขียว 10 ซอง", price: 150, recipeType: "ชา", status: "ACTIVE", imageUrl: "/products/tea.jpg", stock: 25 },
    { id: "P004", name: "น้ำกระท่อมพร้อมดื่ม 300 มล.", price: 45, recipeType: "เครื่องดื่ม", status: "ACTIVE", imageUrl: "/products/drink.jpg", stock: 48 },
    { id: "P005", name: "แคปซูลใบเขียว 60 แคปซูล", price: 290, recipeType: "แคปซูล", status: "ACTIVE", imageUrl: "/products/capsule.jpg", stock: 20 },
    { id: "P006", name: "ใบก้านทองอบแห้ง 100 กรัม", price: 210, recipeType: "ใบแห้ง", status: "ACTIVE", imageUrl: "/products/leaf-gold.jpg", stock: 18 },
  ];
}

export function seedPromos(): Promo[] {
  return [
    { code: "WELCOME10", type: "PERCENT", value: 10, minSpend: 200, active: true },
    { code: "SAVE30", type: "FIXED", value: 30, minSpend: 150, active: true },
  ];
}

function openingLogs(products: Product[]): StockLog[] {
  const ts = new Date().toISOString();
  return products.map((p, i) => ({
    id: `SLOPEN${i + 1}`,
    productId: p.id,
    productName: p.name,
    type: "IN" as const,
    qty: p.stock,
    balance: p.stock,
    timestamp: ts,
    note: "สต๊อกเปิดร้าน",
  }));
}

export type PlaceInput = {
  fulfillment: Fulfillment;
  address: string;
  lat: number | null;
  lng: number | null;
  paymentMethod: PayMethod;
  slipDataUrl: string;
  note: string;
  promoCode: string;
  pointsRequested: number;
};

export type PlaceResult = { ok: true; orderId: string } | { ok: false; error: string };

type PosState = {
  products: Product[];
  orders: Order[];
  customers: Customer[];
  settings: Settings;
  promos: Promo[];
  stockLogs: StockLog[];
  cart: CartLine[];
  session: SessionUser | null;
  setSession: (user: SessionUser | null) => void;
  setQty: (productId: string, qty: number) => void;
  clearCart: () => void;
  placeOrder: (input: PlaceInput) => PlaceResult;
  updateOrderStatus: (orderId: string, status: OrderStatus) => string | null;
  saveProduct: (product: Product, initialStock?: number) => void;
  deleteProduct: (id: string) => void;
  adjustStock: (productId: string, type: "IN" | "OUT", qty: number, note: string) => string | null;
  saveSettings: (settings: Settings) => void;
  savePromo: (promo: Promo) => void;
  deletePromo: (code: string) => void;
  adjustPoints: (lineUserId: string, delta: number) => void;
  resetDemo: () => void;
};

function fresh(): Pick<PosState, "products" | "orders" | "customers" | "settings" | "promos" | "stockLogs" | "cart" | "session"> {
  const products = seedProducts();
  return {
    products,
    orders: [],
    customers: [],
    settings: defaultSettings(),
    promos: seedPromos(),
    stockLogs: openingLogs(products),
    cart: [],
    session: null,
  };
}

function logId() {
  return "SL" + Date.now().toString(36).toUpperCase() + Math.floor(Math.random() * 1000);
}

export const usePos = create<PosState>()(
  persist(
    (set) => ({
      ...fresh(),
      setSession: (user) => set({ session: user }),
      clearCart: () => set({ cart: [] }),
      setQty: (productId, qty) =>
        set((s) => {
          const product = s.products.find((p) => p.id === productId);
          const max = product ? product.stock : 0;
          const nextQty = Math.max(0, Math.min(Math.floor(qty), max));
          const cart = s.cart.filter((c) => c.productId !== productId);
          if (nextQty > 0) cart.push({ productId, qty: nextQty });
          return { cart };
        }),
      placeOrder: (input) => {
        let result: PlaceResult = { ok: false, error: "สั่งซื้อไม่สำเร็จ" };
        set((s) => {
          if (!s.session) {
            result = { ok: false, error: "เข้าสู่ระบบก่อนยืนยันออเดอร์" };
            return s;
          }
          const lines = s.cart.filter((c) => c.qty > 0);
          if (!lines.length) {
            result = { ok: false, error: "ตะกร้ายังว่าง" };
            return s;
          }
          const items: OrderItem[] = [];
          for (const line of lines) {
            const product = s.products.find((p) => p.id === line.productId);
            if (!product || product.status !== "ACTIVE") {
              result = { ok: false, error: "มีสินค้าที่ปิดขายแล้ว" };
              return s;
            }
            if (line.qty > product.stock) {
              result = { ok: false, error: `${product.name} เหลือไม่พอ` };
              return s;
            }
            items.push({ productId: product.id, name: product.name, price: product.price, qty: line.qty });
          }
          const subTotal = items.reduce((sum, it) => sum + it.price * it.qty, 0);
          const code = input.promoCode.trim().toUpperCase();
          const promo = code ? s.promos.find((p) => p.code.toUpperCase() === code) ?? null : null;
          if (code && (!promo || !promo.active)) {
            result = { ok: false, error: "โค้ดส่วนลดใช้ไม่ได้" };
            return s;
          }
          if (promo && subTotal < promo.minSpend) {
            result = { ok: false, error: `โค้ดนี้ใช้เมื่อซื้อครบ ${promo.minSpend} บาท` };
            return s;
          }
          let distance = 0;
          let lat = input.lat;
          let lng = input.lng;
          let address = input.address.trim();
          if (input.fulfillment === "DELIVERY") {
            if (!address) {
              result = { ok: false, error: "กรอกที่อยู่จัดส่ง" };
              return s;
            }
            if (lat == null || lng == null || Number.isNaN(lat) || Number.isNaN(lng)) {
              result = { ok: false, error: "ดึงพิกัด หรือใส่ละติจูด/ลองจิจูดก่อน" };
              return s;
            }
            distance = haversineKm(s.settings.shopLat, s.settings.shopLng, lat, lng);
          } else {
            address = address || "รับที่ร้าน";
            lat = null;
            lng = null;
          }
          if (input.paymentMethod === "TRANSFER" && !input.slipDataUrl) {
            result = { ok: false, error: "อัปโหลดสลิปก่อนยืนยันการโอน" };
            return s;
          }
          const customer = s.customers.find((c) => c.lineUserId === s.session!.lineUserId);
          const quote = quoteOrder({
            subTotal,
            promo,
            pointsRequested: input.pointsRequested,
            pointsBalance: customer?.points ?? 0,
            pointValue: s.settings.pointValue,
            pointsRate: s.settings.pointsRate,
            distanceKm: distance,
            feeBase: s.settings.feeBase,
            feePerKm: s.settings.feePerKm,
            fulfillment: input.fulfillment,
          });
          const now = new Date().toISOString();
          const orderId = "BK" + Date.now().toString(36).toUpperCase();
          const logs: StockLog[] = [];
          const products = s.products.map((p) => {
            const it = items.find((i) => i.productId === p.id);
            if (!it) return p;
            const balance = p.stock - it.qty;
            logs.push({
              id: logId(),
              productId: p.id,
              productName: p.name,
              type: "OUT",
              qty: it.qty,
              balance,
              timestamp: now,
              note: orderId,
            });
            return { ...p, stock: balance };
          });
          const nextCustomer: Customer = {
            lineUserId: s.session.lineUserId,
            name: s.session.name,
            points: (customer?.points ?? 0) - quote.pointsUsed + quote.pointsEarned,
            totalSpent: (customer?.totalSpent ?? 0) + quote.total,
            lastOrderDate: now,
          };
          const order: Order = {
            orderId,
            timestamp: now,
            lineUserId: s.session.lineUserId,
            customerName: s.session.name,
            items,
            subTotal,
            discount: quote.discount,
            pointsUsed: quote.pointsUsed,
            pointsEarned: quote.pointsEarned,
            deliveryFee: quote.delivery,
            total: quote.total,
            paymentMethod: input.paymentMethod,
            slipUrl: input.paymentMethod === "TRANSFER" ? input.slipDataUrl : "",
            lat,
            lng,
            distance: Math.round(distance * 100) / 100,
            address,
            fulfillment: input.fulfillment,
            status: "PENDING",
            note: input.note.trim(),
            promoCode: promo ? promo.code : "",
          };
          const customers = customer
            ? s.customers.map((c) => (c.lineUserId === nextCustomer.lineUserId ? nextCustomer : c))
            : [nextCustomer, ...s.customers];
          result = { ok: true, orderId };
          return { products, orders: [order, ...s.orders], customers, stockLogs: [...logs, ...s.stockLogs], cart: [] };
        });
        return result;
      },
      updateOrderStatus: (orderId, status) => {
        let error: string | null = null;
        set((s) => {
          const order = s.orders.find((o) => o.orderId === orderId);
          if (!order) {
            error = "ไม่พบออเดอร์";
            return s;
          }
          if (order.status === status) return s;
          const allowed: Record<OrderStatus, OrderStatus[]> = {
            PENDING: ["DELIVERING", "CANCELLED"],
            DELIVERING: ["COMPLETED", "CANCELLED"],
            COMPLETED: [],
            CANCELLED: [],
          };
          if (!allowed[order.status].includes(status)) {
            error = "เปลี่ยนสถานะนี้ไม่ได้";
            return s;
          }
          let products = s.products;
          let stockLogs = s.stockLogs;
          let customers = s.customers;
          if (status === "CANCELLED") {
            const now = new Date().toISOString();
            const logs: StockLog[] = [];
            products = products.map((p) => {
              const it = order.items.find((i) => i.productId === p.id);
              if (!it) return p;
              const balance = p.stock + it.qty;
              logs.push({
                id: logId(),
                productId: p.id,
                productName: p.name,
                type: "IN",
                qty: it.qty,
                balance,
                timestamp: now,
                note: `คืนสต๊อก ${order.orderId}`,
              });
              return { ...p, stock: balance };
            });
            stockLogs = [...logs, ...stockLogs];
            customers = customers.map((c) => {
              if (c.lineUserId !== order.lineUserId) return c;
              return {
                ...c,
                points: Math.max(0, c.points + order.pointsUsed - order.pointsEarned),
                totalSpent: Math.max(0, c.totalSpent - order.total),
              };
            });
          }
          return {
            products,
            stockLogs,
            customers,
            orders: s.orders.map((o) => (o.orderId === orderId ? { ...o, status } : o)),
          };
        });
        return error;
      },
      saveProduct: (product, initialStock) =>
        set((s) => {
          const exists = s.products.some((p) => p.id === product.id);
          if (!exists) {
            const stock = Math.max(0, Math.floor(initialStock ?? product.stock ?? 0));
            const next = { ...product, stock, price: Math.max(0, Math.round(product.price)) };
            const log: StockLog = {
              id: logId(),
              productId: next.id,
              productName: next.name,
              type: "IN",
              qty: stock,
              balance: stock,
              timestamp: new Date().toISOString(),
              note: "เปิดสินค้าใหม่",
            };
            return { products: [...s.products, next], stockLogs: [log, ...s.stockLogs] };
          }
          return {
            products: s.products.map((p) =>
              p.id === product.id
                ? { ...p, name: product.name, price: Math.max(0, Math.round(product.price)), recipeType: product.recipeType, status: product.status, imageUrl: product.imageUrl }
                : p,
            ),
          };
        }),
      deleteProduct: (id) =>
        set((s) => ({
          products: s.products.filter((p) => p.id !== id),
          cart: s.cart.filter((c) => c.productId !== id),
        })),
      adjustStock: (productId, type, qty, note) => {
        let error: string | null = null;
        const amount = Math.floor(qty);
        if (!Number.isFinite(amount) || amount <= 0) return "จำนวนต้องมากกว่า 0";
        set((s) => {
          const product = s.products.find((p) => p.id === productId);
          if (!product) {
            error = "ไม่พบสินค้า";
            return s;
          }
          const balance = type === "IN" ? product.stock + amount : product.stock - amount;
          if (balance < 0) {
            error = "สต๊อกไม่พอให้ตัด";
            return s;
          }
          const log: StockLog = {
            id: logId(),
            productId,
            productName: product.name,
            type,
            qty: amount,
            balance,
            timestamp: new Date().toISOString(),
            note: note.trim() || (type === "IN" ? "รับเข้า" : "ตัดออก"),
          };
          return {
            products: s.products.map((p) => (p.id === productId ? { ...p, stock: balance } : p)),
            stockLogs: [log, ...s.stockLogs],
          };
        });
        return error;
      },
      saveSettings: (settings) => set({ settings }),
      savePromo: (promo) =>
        set((s) => {
          const code = promo.code.trim().toUpperCase();
          const next = { ...promo, code };
          const exists = s.promos.some((p) => p.code === code);
          return { promos: exists ? s.promos.map((p) => (p.code === code ? next : p)) : [...s.promos, next] };
        }),
      deletePromo: (code) => set((s) => ({ promos: s.promos.filter((p) => p.code !== code) })),
      adjustPoints: (lineUserId, delta) =>
        set((s) => ({
          customers: s.customers.map((c) =>
            c.lineUserId === lineUserId ? { ...c, points: Math.max(0, Math.round(c.points + delta)) } : c,
          ),
        })),
      resetDemo: () => set({ ...fresh() }),
    }),
    {
      name: "bai-khiao-pos",
      version: 1,
      skipHydration: true,
      storage: createJSONStorage(() => localStorage),
    },
  ),
);
