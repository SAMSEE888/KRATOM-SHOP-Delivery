import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Store, c as QrCode, d as MapPin, f as Leaf, l as Plus, n as Upload, o as ShoppingBag, p as Banknote, r as Truck, t as X, u as Minus } from "../_libs/lucide-react.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ready-BfabTftk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function tlv(id, value) {
	return id + value.length.toString().padStart(2, "0") + value;
}
/** CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF) ตามสเปก EMVCo ของ PromptPay */
function crc16Ccitt(payload) {
	let crc = 65535;
	for (let i = 0; i < payload.length; i++) {
		crc ^= payload.charCodeAt(i) << 8;
		for (let bit = 0; bit < 8; bit++) if (crc & 32768) crc = (crc << 1 ^ 4129) & 65535;
		else crc = crc << 1 & 65535;
	}
	return crc.toString(16).toUpperCase().padStart(4, "0");
}
/** เบอร์มือถือ = tag 01 (เติม 0066 ให้ครบ 13), เลข 13 หลัก = tag 02, ยาวกว่า = tag 03 */
function formatPromptPayTarget(raw) {
	const id = String(raw || "").replace(/[^0-9]/g, "");
	if (id.length >= 15) return {
		type: "03",
		value: id
	};
	if (id.length >= 13) return {
		type: "02",
		value: id
	};
	return {
		type: "01",
		value: ("0000000000000" + id.replace(/^0/, "66")).slice(-13)
	};
}
/** Dynamic PromptPay QR (EMVCo) — ใส่ยอดเงินเมื่อ amount > 0 */
function buildPromptPayPayload(promptPayId, amount) {
	const target = formatPromptPayTarget(promptPayId);
	const amt = Number(amount);
	const hasAmount = Number.isFinite(amt) && amt > 0;
	const merchant = tlv("00", "A000000677010111") + tlv(target.type, target.value);
	let body = "";
	body += tlv("00", "01");
	body += tlv("01", hasAmount ? "12" : "11");
	body += tlv("29", merchant);
	body += tlv("58", "TH");
	body += tlv("53", "764");
	if (hasAmount) body += tlv("54", amt.toFixed(2));
	const withCrcMark = body + "6304";
	return withCrcMark + crc16Ccitt(withCrcMark);
}
/** ระยะทางกิโลเมตรระหว่างสองพิกัด (Haversine, รัศมีโลก 6371 กม.) */
function haversineKm(lat1, lng1, lat2, lng2) {
	const R = 6371;
	const rad = Math.PI / 180;
	const dLat = (lat2 - lat1) * rad;
	const dLng = (lng2 - lng1) * rad;
	const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLng / 2) ** 2;
	return 2 * R * Math.asin(Math.min(1, Math.sqrt(Math.max(0, a))));
}
/** ค่าส่ง = ปัดขึ้น(ค่าเริ่มต้น + ระยะทางกม. × ค่าต่อกม.) */
function deliveryFeeBaht(km, feeBase, feePerKm) {
	if (!Number.isFinite(km) || km < 0) return 0;
	return Math.max(0, Math.ceil(Number(feeBase) + km * Number(feePerKm)));
}
function promoDiscount(subTotal, promo) {
	if (!promo || !promo.active) return 0;
	if (subTotal + 1e-9 < Number(promo.minSpend)) return 0;
	if (promo.type === "PERCENT") return Math.min(subTotal, Math.floor(subTotal * Number(promo.value) / 100));
	return Math.min(subTotal, Math.round(Number(promo.value)));
}
function quoteOrder(input) {
	const promoOff = promoDiscount(input.subTotal, input.promo);
	const afterPromo = Math.max(0, input.subTotal - promoOff);
	const pointValue = Math.max(.01, Number(input.pointValue) || 1);
	const maxByMoney = Math.floor(afterPromo / pointValue);
	const pointsUsed = Math.max(0, Math.min(Math.floor(Number(input.pointsRequested) || 0), Math.floor(Number(input.pointsBalance) || 0), maxByMoney));
	const pointsOff = Math.min(afterPromo, pointsUsed * pointValue);
	const discount = promoOff + pointsOff;
	const delivery = input.fulfillment === "PICKUP" ? 0 : deliveryFeeBaht(input.distanceKm, input.feeBase, input.feePerKm);
	const netGoods = Math.max(0, input.subTotal - discount);
	const rate = Number(input.pointsRate) || 0;
	return {
		promoOff,
		pointsUsed,
		pointsOff,
		discount,
		delivery,
		pointsEarned: rate > 0 ? Math.floor(netGoods / rate) : 0,
		total: netGoods + delivery,
		netGoods
	};
}
function baht(n) {
	return new Intl.NumberFormat("th-TH", {
		style: "currency",
		currency: "THB",
		maximumFractionDigits: 0
	}).format(Math.round(Number(n) || 0));
}
function todayBangkok(iso) {
	return new Intl.DateTimeFormat("en-CA", {
		timeZone: "Asia/Bangkok",
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).format(iso ? new Date(iso) : /* @__PURE__ */ new Date());
}
function formatWhen(iso) {
	return new Intl.DateTimeFormat("th-TH", {
		timeZone: "Asia/Bangkok",
		dateStyle: "medium",
		timeStyle: "short"
	}).format(new Date(iso));
}
var defaultSettings = () => ({
	shopName: "ใบเขียว",
	shopPhone: "02-000-0000",
	promptPayId: "0899999991",
	shopLat: 13.7563,
	shopLng: 100.5018,
	feeBase: 25,
	feePerKm: 8,
	pointsRate: 50,
	pointValue: 1,
	lineChannelToken: "",
	lineAdminUserId: "",
	adminPin: "2580"
});
function seedProducts() {
	return [
		{
			id: "P001",
			name: "ใบกระท่อมแดงอบแห้ง 100 กรัม",
			price: 180,
			recipeType: "ใบแห้ง",
			status: "ACTIVE",
			imageUrl: "/products/leaf-red.jpg",
			stock: 40
		},
		{
			id: "P002",
			name: "ผงกระท่อมคัดใบ 50 กรัม",
			price: 220,
			recipeType: "ผง",
			status: "ACTIVE",
			imageUrl: "/products/powder.jpg",
			stock: 30
		},
		{
			id: "P003",
			name: "ชาชงใบเขียว 10 ซอง",
			price: 150,
			recipeType: "ชา",
			status: "ACTIVE",
			imageUrl: "/products/tea.jpg",
			stock: 25
		},
		{
			id: "P004",
			name: "น้ำกระท่อมพร้อมดื่ม 300 มล.",
			price: 45,
			recipeType: "เครื่องดื่ม",
			status: "ACTIVE",
			imageUrl: "/products/drink.jpg",
			stock: 48
		},
		{
			id: "P005",
			name: "แคปซูลใบเขียว 60 แคปซูล",
			price: 290,
			recipeType: "แคปซูล",
			status: "ACTIVE",
			imageUrl: "/products/capsule.jpg",
			stock: 20
		},
		{
			id: "P006",
			name: "ใบก้านทองอบแห้ง 100 กรัม",
			price: 210,
			recipeType: "ใบแห้ง",
			status: "ACTIVE",
			imageUrl: "/products/leaf-gold.jpg",
			stock: 18
		}
	];
}
function seedPromos() {
	return [{
		code: "WELCOME10",
		type: "PERCENT",
		value: 10,
		minSpend: 200,
		active: true
	}, {
		code: "SAVE30",
		type: "FIXED",
		value: 30,
		minSpend: 150,
		active: true
	}];
}
function openingLogs(products) {
	const ts = (/* @__PURE__ */ new Date()).toISOString();
	return products.map((p, i) => ({
		id: `SLOPEN${i + 1}`,
		productId: p.id,
		productName: p.name,
		type: "IN",
		qty: p.stock,
		balance: p.stock,
		timestamp: ts,
		note: "สต๊อกเปิดร้าน"
	}));
}
function fresh() {
	const products = seedProducts();
	return {
		products,
		orders: [],
		customers: [],
		settings: defaultSettings(),
		promos: seedPromos(),
		stockLogs: openingLogs(products),
		cart: [],
		session: null
	};
}
function logId() {
	return "SL" + Date.now().toString(36).toUpperCase() + Math.floor(Math.random() * 1e3);
}
var usePos = create()(persist((set) => ({
	...fresh(),
	setSession: (user) => set({ session: user }),
	clearCart: () => set({ cart: [] }),
	setQty: (productId, qty) => set((s) => {
		const product = s.products.find((p) => p.id === productId);
		const max = product ? product.stock : 0;
		const nextQty = Math.max(0, Math.min(Math.floor(qty), max));
		const cart = s.cart.filter((c) => c.productId !== productId);
		if (nextQty > 0) cart.push({
			productId,
			qty: nextQty
		});
		return { cart };
	}),
	placeOrder: (input) => {
		let result = {
			ok: false,
			error: "สั่งซื้อไม่สำเร็จ"
		};
		set((s) => {
			if (!s.session) {
				result = {
					ok: false,
					error: "เข้าสู่ระบบก่อนยืนยันออเดอร์"
				};
				return s;
			}
			const lines = s.cart.filter((c) => c.qty > 0);
			if (!lines.length) {
				result = {
					ok: false,
					error: "ตะกร้ายังว่าง"
				};
				return s;
			}
			const items = [];
			for (const line of lines) {
				const product = s.products.find((p) => p.id === line.productId);
				if (!product || product.status !== "ACTIVE") {
					result = {
						ok: false,
						error: "มีสินค้าที่ปิดขายแล้ว"
					};
					return s;
				}
				if (line.qty > product.stock) {
					result = {
						ok: false,
						error: `${product.name} เหลือไม่พอ`
					};
					return s;
				}
				items.push({
					productId: product.id,
					name: product.name,
					price: product.price,
					qty: line.qty
				});
			}
			const subTotal = items.reduce((sum, it) => sum + it.price * it.qty, 0);
			const code = input.promoCode.trim().toUpperCase();
			const promo = code ? s.promos.find((p) => p.code.toUpperCase() === code) ?? null : null;
			if (code && (!promo || !promo.active)) {
				result = {
					ok: false,
					error: "โค้ดส่วนลดใช้ไม่ได้"
				};
				return s;
			}
			if (promo && subTotal < promo.minSpend) {
				result = {
					ok: false,
					error: `โค้ดนี้ใช้เมื่อซื้อครบ ${promo.minSpend} บาท`
				};
				return s;
			}
			let distance = 0;
			let lat = input.lat;
			let lng = input.lng;
			let address = input.address.trim();
			if (input.fulfillment === "DELIVERY") {
				if (!address) {
					result = {
						ok: false,
						error: "กรอกที่อยู่จัดส่ง"
					};
					return s;
				}
				if (lat == null || lng == null || Number.isNaN(lat) || Number.isNaN(lng)) {
					result = {
						ok: false,
						error: "ดึงพิกัด หรือใส่ละติจูด/ลองจิจูดก่อน"
					};
					return s;
				}
				distance = haversineKm(s.settings.shopLat, s.settings.shopLng, lat, lng);
			} else {
				address = address || "รับที่ร้าน";
				lat = null;
				lng = null;
			}
			if (input.paymentMethod === "TRANSFER" && !input.slipDataUrl) {
				result = {
					ok: false,
					error: "อัปโหลดสลิปก่อนยืนยันการโอน"
				};
				return s;
			}
			const customer = s.customers.find((c) => c.lineUserId === s.session.lineUserId);
			const quote = quoteOrder({
				subTotal,
				promo,
				pointsRequested: input.pointsRequested,
				pointsBalance: customer?.points ?? 0,
				pointValue: s.settings.pointValue,
				pointsRate: s.settings.pointsRate,
				distanceKm: distance,
				feeBase: s.settings.feeBase,
				feePerKm: s.settings.feePerKm,
				fulfillment: input.fulfillment
			});
			const now = (/* @__PURE__ */ new Date()).toISOString();
			const orderId = "BK" + Date.now().toString(36).toUpperCase();
			const logs = [];
			const products = s.products.map((p) => {
				const it = items.find((i) => i.productId === p.id);
				if (!it) return p;
				const balance = p.stock - it.qty;
				logs.push({
					id: logId(),
					productId: p.id,
					productName: p.name,
					type: "OUT",
					qty: it.qty,
					balance,
					timestamp: now,
					note: orderId
				});
				return {
					...p,
					stock: balance
				};
			});
			const nextCustomer = {
				lineUserId: s.session.lineUserId,
				name: s.session.name,
				points: (customer?.points ?? 0) - quote.pointsUsed + quote.pointsEarned,
				totalSpent: (customer?.totalSpent ?? 0) + quote.total,
				lastOrderDate: now
			};
			const order = {
				orderId,
				timestamp: now,
				lineUserId: s.session.lineUserId,
				customerName: s.session.name,
				items,
				subTotal,
				discount: quote.discount,
				pointsUsed: quote.pointsUsed,
				pointsEarned: quote.pointsEarned,
				deliveryFee: quote.delivery,
				total: quote.total,
				paymentMethod: input.paymentMethod,
				slipUrl: input.paymentMethod === "TRANSFER" ? input.slipDataUrl : "",
				lat,
				lng,
				distance: Math.round(distance * 100) / 100,
				address,
				fulfillment: input.fulfillment,
				status: "PENDING",
				note: input.note.trim(),
				promoCode: promo ? promo.code : ""
			};
			const customers = customer ? s.customers.map((c) => c.lineUserId === nextCustomer.lineUserId ? nextCustomer : c) : [nextCustomer, ...s.customers];
			result = {
				ok: true,
				orderId
			};
			return {
				products,
				orders: [order, ...s.orders],
				customers,
				stockLogs: [...logs, ...s.stockLogs],
				cart: []
			};
		});
		return result;
	},
	updateOrderStatus: (orderId, status) => {
		let error = null;
		set((s) => {
			const order = s.orders.find((o) => o.orderId === orderId);
			if (!order) {
				error = "ไม่พบออเดอร์";
				return s;
			}
			if (order.status === status) return s;
			if (!{
				PENDING: ["DELIVERING", "CANCELLED"],
				DELIVERING: ["COMPLETED", "CANCELLED"],
				COMPLETED: [],
				CANCELLED: []
			}[order.status].includes(status)) {
				error = "เปลี่ยนสถานะนี้ไม่ได้";
				return s;
			}
			let products = s.products;
			let stockLogs = s.stockLogs;
			let customers = s.customers;
			if (status === "CANCELLED") {
				const now = (/* @__PURE__ */ new Date()).toISOString();
				const logs = [];
				products = products.map((p) => {
					const it = order.items.find((i) => i.productId === p.id);
					if (!it) return p;
					const balance = p.stock + it.qty;
					logs.push({
						id: logId(),
						productId: p.id,
						productName: p.name,
						type: "IN",
						qty: it.qty,
						balance,
						timestamp: now,
						note: `คืนสต๊อก ${order.orderId}`
					});
					return {
						...p,
						stock: balance
					};
				});
				stockLogs = [...logs, ...stockLogs];
				customers = customers.map((c) => {
					if (c.lineUserId !== order.lineUserId) return c;
					return {
						...c,
						points: Math.max(0, c.points + order.pointsUsed - order.pointsEarned),
						totalSpent: Math.max(0, c.totalSpent - order.total)
					};
				});
			}
			return {
				products,
				stockLogs,
				customers,
				orders: s.orders.map((o) => o.orderId === orderId ? {
					...o,
					status
				} : o)
			};
		});
		return error;
	},
	saveProduct: (product, initialStock) => set((s) => {
		if (!s.products.some((p) => p.id === product.id)) {
			const stock = Math.max(0, Math.floor(initialStock ?? product.stock ?? 0));
			const next = {
				...product,
				stock,
				price: Math.max(0, Math.round(product.price))
			};
			const log = {
				id: logId(),
				productId: next.id,
				productName: next.name,
				type: "IN",
				qty: stock,
				balance: stock,
				timestamp: (/* @__PURE__ */ new Date()).toISOString(),
				note: "เปิดสินค้าใหม่"
			};
			return {
				products: [...s.products, next],
				stockLogs: [log, ...s.stockLogs]
			};
		}
		return { products: s.products.map((p) => p.id === product.id ? {
			...p,
			name: product.name,
			price: Math.max(0, Math.round(product.price)),
			recipeType: product.recipeType,
			status: product.status,
			imageUrl: product.imageUrl
		} : p) };
	}),
	deleteProduct: (id) => set((s) => ({
		products: s.products.filter((p) => p.id !== id),
		cart: s.cart.filter((c) => c.productId !== id)
	})),
	adjustStock: (productId, type, qty, note) => {
		let error = null;
		const amount = Math.floor(qty);
		if (!Number.isFinite(amount) || amount <= 0) return "จำนวนต้องมากกว่า 0";
		set((s) => {
			const product = s.products.find((p) => p.id === productId);
			if (!product) {
				error = "ไม่พบสินค้า";
				return s;
			}
			const balance = type === "IN" ? product.stock + amount : product.stock - amount;
			if (balance < 0) {
				error = "สต๊อกไม่พอให้ตัด";
				return s;
			}
			const log = {
				id: logId(),
				productId,
				productName: product.name,
				type,
				qty: amount,
				balance,
				timestamp: (/* @__PURE__ */ new Date()).toISOString(),
				note: note.trim() || (type === "IN" ? "รับเข้า" : "ตัดออก")
			};
			return {
				products: s.products.map((p) => p.id === productId ? {
					...p,
					stock: balance
				} : p),
				stockLogs: [log, ...s.stockLogs]
			};
		});
		return error;
	},
	saveSettings: (settings) => set({ settings }),
	savePromo: (promo) => set((s) => {
		const code = promo.code.trim().toUpperCase();
		const next = {
			...promo,
			code
		};
		return { promos: s.promos.some((p) => p.code === code) ? s.promos.map((p) => p.code === code ? next : p) : [...s.promos, next] };
	}),
	deletePromo: (code) => set((s) => ({ promos: s.promos.filter((p) => p.code !== code) })),
	adjustPoints: (lineUserId, delta) => set((s) => ({ customers: s.customers.map((c) => c.lineUserId === lineUserId ? {
		...c,
		points: Math.max(0, Math.round(c.points + delta))
	} : c) })),
	resetDemo: () => set({ ...fresh() })
}), {
	name: "bai-khiao-pos",
	version: 1,
	skipHydration: true,
	storage: createJSONStorage(() => localStorage)
}));
function BootScreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-4 grid size-14 place-items-center rounded-2xl bg-primary text-primary-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, {
						className: "size-7",
						"aria-hidden": "true"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold tracking-tight",
					children: "ใบเขียว"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "กำลังเปิดร้าน"
				})
			]
		})
	});
}
function fileToSlip(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onerror = () => reject(/* @__PURE__ */ new Error("อ่านไฟล์ไม่สำเร็จ"));
		reader.onload = () => {
			const img = new Image();
			img.onload = () => {
				const scale = Math.min(1, 1e3 / Math.max(img.width, img.height));
				const canvas = document.createElement("canvas");
				canvas.width = Math.max(1, Math.round(img.width * scale));
				canvas.height = Math.max(1, Math.round(img.height * scale));
				const ctx = canvas.getContext("2d");
				if (!ctx) {
					resolve(String(reader.result));
					return;
				}
				ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
				resolve(canvas.toDataURL("image/jpeg", .72));
			};
			img.onerror = () => reject(/* @__PURE__ */ new Error("ไฟล์รูปไม่ถูกต้อง"));
			img.src = String(reader.result);
		};
		reader.readAsDataURL(file);
	});
}
function PromptQr({ payload }) {
	const [src, setSrc] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let dead = false;
		import("../_libs/qrcode.mjs").then((n) => /* @__PURE__ */ __toESM(n.t())).then((QR) => {
			QR.toDataURL(payload, {
				margin: 1,
				width: 360,
				errorCorrectionLevel: "M",
				color: {
					dark: "#06281c",
					light: "#ffffff"
				}
			}).then((url) => {
				if (!dead) setSrc(url);
			});
		});
		return () => {
			dead = true;
		};
	}, [payload]);
	if (!src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid h-56 w-56 place-items-center text-sm text-muted",
		children: "กำลังสร้าง QR"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: "คิวอาร์พร้อมเพย์ตามยอดสั่งซื้อ",
		className: "h-56 w-56"
	});
}
function Storefront() {
	const products = usePos((s) => s.products);
	const cart = usePos((s) => s.cart);
	const session = usePos((s) => s.session);
	const settings = usePos((s) => s.settings);
	const promos = usePos((s) => s.promos);
	const customers = usePos((s) => s.customers);
	const orders = usePos((s) => s.orders);
	const setQty = usePos((s) => s.setQty);
	const setSession = usePos((s) => s.setSession);
	const placeOrder = usePos((s) => s.placeOrder);
	const [age, setAge] = (0, import_react.useState)("wait");
	const [cat, setCat] = (0, import_react.useState)("ทั้งหมด");
	const [view, setView] = (0, import_react.useState)("shop");
	const [loginOpen, setLoginOpen] = (0, import_react.useState)(false);
	const [draftName, setDraftName] = (0, import_react.useState)("");
	const [fulfillment, setFulfillment] = (0, import_react.useState)("DELIVERY");
	const [address, setAddress] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [lat, setLat] = (0, import_react.useState)("");
	const [lng, setLng] = (0, import_react.useState)("");
	const [geoMsg, setGeoMsg] = (0, import_react.useState)("");
	const [pay, setPay] = (0, import_react.useState)("CASH");
	const [slip, setSlip] = (0, import_react.useState)("");
	const [promoCode, setPromoCode] = (0, import_react.useState)("");
	const [points, setPoints] = (0, import_react.useState)(0);
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [doneId, setDoneId] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setAge(localStorage.getItem("bai-khiao-age") === "yes" ? "yes" : "ask");
	}, []);
	const active = products.filter((p) => p.status === "ACTIVE");
	const cats = ["ทั้งหมด", ...Array.from(new Set(active.map((p) => p.recipeType)))];
	const shown = active.filter((p) => cat === "ทั้งหมด" || p.recipeType === cat);
	const lines = cart.map((line) => ({
		...line,
		product: products.find((p) => p.id === line.productId)
	})).filter((line) => line.product && line.qty > 0);
	const count = lines.reduce((sum, line) => sum + line.qty, 0);
	const subTotal = lines.reduce((sum, line) => sum + line.product.price * line.qty, 0);
	const balance = customers.find((c) => c.lineUserId === session?.lineUserId)?.points ?? 0;
	const latN = Number(lat);
	const lngN = Number(lng);
	const hasGeo = lat.trim() !== "" && lng.trim() !== "" && Number.isFinite(latN) && Number.isFinite(lngN);
	const distance = hasGeo ? haversineKm(settings.shopLat, settings.shopLng, latN, lngN) : 0;
	const code = promoCode.trim().toUpperCase();
	const promo = code ? promos.find((p) => p.code.toUpperCase() === code) ?? null : null;
	const quote = quoteOrder({
		subTotal,
		promo,
		pointsRequested: points,
		pointsBalance: balance,
		pointValue: settings.pointValue,
		pointsRate: settings.pointsRate,
		distanceKm: distance,
		feeBase: settings.feeBase,
		feePerKm: settings.feePerKm,
		fulfillment
	});
	const promoHint = !code ? "" : !promo || !promo.active ? "ไม่พบโค้ดนี้" : subTotal < promo.minSpend ? `ใช้ได้เมื่อซื้อครบ ${baht(promo.minSpend)}` : `ใช้โค้ด ${promo.code} แล้ว`;
	const maxPoints = Math.min(balance, Math.floor(Math.max(0, subTotal - quote.promoOff) / Math.max(.01, settings.pointValue)));
	const payload = (0, import_react.useMemo)(() => buildPromptPayPayload(settings.promptPayId, quote.total), [settings.promptPayId, quote.total]);
	const done = orders.find((o) => o.orderId === doneId);
	function acceptAge() {
		localStorage.setItem("bai-khiao-age", "yes");
		setAge("yes");
	}
	function login() {
		const name = draftName.trim();
		if (!name) {
			setError("ใส่ชื่อที่ต้องการให้ร้านเรียก");
			return;
		}
		const lineUserId = session?.lineUserId || `LOCAL-${Math.random().toString(36).slice(2, 10).toUpperCase()}`;
		setSession({
			lineUserId,
			name,
			pictureUrl: ""
		});
		setLoginOpen(false);
		setError("");
	}
	async function locate() {
		setGeoMsg("กำลังขอพิกัด…");
		try {
			const pos = await new Promise((resolve, reject) => {
				if (!navigator.geolocation) {
					reject(/* @__PURE__ */ new Error("อุปกรณ์นี้ไม่เปิดพิกัด"));
					return;
				}
				navigator.geolocation.getCurrentPosition(resolve, () => reject(/* @__PURE__ */ new Error("ไม่ได้รับอนุญาตให้ใช้พิกัด")), {
					enableHighAccuracy: true,
					timeout: 12e3,
					maximumAge: 15e3
				});
			});
			setLat(pos.coords.latitude.toFixed(6));
			setLng(pos.coords.longitude.toFixed(6));
			setGeoMsg("ใช้พิกัดปัจจุบันแล้ว");
		} catch (err) {
			setGeoMsg(err instanceof Error ? err.message : "ดึงพิกัดไม่สำเร็จ");
		}
	}
	function useSamplePin() {
		setLat((settings.shopLat + .0108).toFixed(6));
		setLng((settings.shopLng + .0042).toFixed(6));
		setGeoMsg("ใส่พิกัดตัวอย่างห่างจากร้านประมาณ 1.3 กม.");
	}
	async function onSlip(file) {
		if (!file) return;
		setError("");
		try {
			setSlip(await fileToSlip(file));
		} catch (err) {
			setError(err instanceof Error ? err.message : "อัปโหลดสลิปไม่สำเร็จ");
		}
	}
	function submit() {
		setBusy(true);
		setError("");
		const result = placeOrder({
			fulfillment,
			address,
			lat: hasGeo ? latN : null,
			lng: hasGeo ? lngN : null,
			paymentMethod: pay,
			slipDataUrl: slip,
			note,
			promoCode: code,
			pointsRequested: points
		});
		setBusy(false);
		if (!result.ok) {
			setError(result.error);
			return;
		}
		setDoneId(result.orderId);
		setSlip("");
		setPoints(0);
		setPromoCode("");
		setView("done");
	}
	if (age === "wait") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	if (age !== "yes") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center px-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "glass w-full max-w-md rounded-3xl p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-5 grid size-12 place-items-center rounded-2xl bg-primary text-primary-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, {
						className: "size-6",
						"aria-hidden": "true"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-primary",
					children: "จำหน่ายเฉพาะผู้มีอายุ 18 ปีขึ้นไป"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-3xl font-semibold tracking-tight",
					children: settings.shopName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-6 text-muted",
					children: "สินค้าสมุนไพรตามกฎหมายไทย ไม่มีสรรพคุณรักษาโรค ยืนยันอายุก่อนเข้าหน้าร้าน"
				}),
				age === "no" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 rounded-2xl bg-elevated px-4 py-3 text-sm text-danger",
					role: "alert",
					children: "ขออภัย ร้านนี้ให้บริการเฉพาะผู้มีอายุ 18 ปีบริบูรณ์"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: acceptAge,
						className: "min-h-11 rounded-2xl bg-primary px-4 font-medium text-primary-fg",
						children: "ฉันอายุ 18 ปีขึ้นไป"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setAge("no"),
						className: "min-h-11 rounded-2xl bg-elevated px-4 text-muted",
						children: "ยังไม่ถึง 18 ปี"
					})]
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto min-h-screen max-w-lg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "glass sticky top-0 z-20 px-4 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-11 shrink-0 place-items-center rounded-2xl bg-primary text-primary-fg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, {
								className: "size-5",
								"aria-hidden": "true"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "truncate text-lg font-semibold leading-tight",
								children: settings.shopName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `tel:${settings.shopPhone}`,
								className: "text-sm text-muted",
								children: settings.shopPhone
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => session ? setSession(null) : setLoginOpen(true),
							className: "min-h-11 rounded-2xl bg-elevated px-3 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted",
								children: session ? "แต้มสะสม" : "เข้าสู่ระบบ"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm font-medium text-primary",
								children: session ? `${balance} แต้ม` : "ลูกค้า"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "px-4 pb-28 pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-4 text-sm leading-6 text-muted",
						children: [
							"สั่งรับที่ร้านหรือให้ส่งถึงที่ ค่าส่งคิดจากระยะจริง · ได้ 1 แต้มทุก ",
							settings.pointsRate,
							" บาท"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "no-scrollbar -mx-4 mb-4 flex gap-2 overflow-x-auto px-4",
						children: cats.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setCat(item),
							className: `min-h-11 shrink-0 rounded-full px-4 text-sm ${item === cat ? "bg-primary text-primary-fg" : "bg-elevated text-muted"}`,
							children: item
						}, item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid grid-cols-2 gap-3",
						children: shown.map((product) => {
							const qty = cart.find((c) => c.productId === product.id)?.qty ?? 0;
							const soldOut = product.stock <= 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "overflow-hidden rounded-3xl border border-line bg-surface",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative aspect-square bg-elevated",
									children: [product.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: product.imageUrl,
										alt: product.name,
										className: "h-full w-full object-cover"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid h-full place-items-center text-primary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, {
											className: "size-8",
											"aria-hidden": "true"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute left-2 top-2 rounded-full bg-bg/80 px-2 py-1 text-xs",
										children: product.recipeType
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2 p-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "line-clamp-2 min-h-11 text-sm font-medium leading-5",
											children: product.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-end justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-base font-semibold text-primary",
												children: baht(product.price)
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs ${product.stock <= 5 ? "text-danger" : "text-muted"}`,
												children: soldOut ? "หมด" : `เหลือ ${product.stock}`
											})]
										}),
										qty > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between rounded-2xl bg-elevated p-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													"aria-label": "ลดจำนวน",
													onClick: () => setQty(product.id, qty - 1),
													className: "grid size-11 place-items-center rounded-xl",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-sm font-medium",
													children: qty
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													"aria-label": "เพิ่มจำนวน",
													disabled: qty >= product.stock,
													onClick: () => setQty(product.id, qty + 1),
													className: "grid size-11 place-items-center rounded-xl disabled:opacity-40",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
												})
											]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: soldOut,
											onClick: () => setQty(product.id, 1),
											className: "min-h-11 w-full rounded-2xl bg-primary text-sm font-medium text-primary-fg disabled:bg-elevated disabled:text-muted",
											children: soldOut ? "สินค้าหมด" : "ใส่ตะกร้า"
										})
									]
								})]
							}, product.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-8 text-center text-xs leading-5 text-muted",
						children: [
							"จำหน่ายเฉพาะอายุ 18+ · ใน LINE จะล็อกอินโปรไฟล์จริงผ่าน LIFF",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/admin",
								className: "text-primary",
								children: "หลังบ้าน"
							})
						]
					})
				]
			}),
			count > 0 && view === "shop" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-20 mx-auto max-w-lg px-4 safe-b",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						setError("");
						if (!session) {
							setLoginOpen(true);
							return;
						}
						setView("checkout");
					},
					className: "mb-3 flex min-h-14 w-full items-center justify-between rounded-3xl bg-primary px-4 text-primary-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 font-medium",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-5" }),
							" ",
							count,
							" ชิ้น"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-semibold",
						children: [baht(subTotal), " · สั่งเลย"]
					})]
				})
			}) : null,
			loginOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 grid place-items-end bg-bg/70 px-4 pb-6 sm:place-items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "glass w-full max-w-md rounded-3xl p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xl font-semibold",
								children: "เข้าสู่ระบบลูกค้า"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "ปิด",
								onClick: () => setLoginOpen(false),
								className: "grid size-11 place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-6 text-muted",
							children: "พรีวิวนี้จำลองโปรไฟล์ LINE ชื่อและแต้มจะผูกกับลูกค้าคนนี้จนกว่าจะสลับ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-4 block text-sm text-muted",
							htmlFor: "cust-name",
							children: "ชื่อที่ให้ร้านเรียก"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "cust-name",
							value: draftName,
							onChange: (e) => setDraftName(e.target.value),
							className: "mt-1 min-h-11 w-full rounded-2xl border border-line bg-elevated px-3 text-base",
							placeholder: "เช่น คุณเมย์"
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-danger",
							role: "alert",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: login,
							className: "mt-4 min-h-11 w-full rounded-2xl bg-primary font-medium text-primary-fg",
							children: "เริ่มสั่งซื้อ"
						})
					]
				})
			}) : null,
			view === "checkout" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "fixed inset-0 z-30 overflow-y-auto bg-bg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto min-h-full max-w-lg px-4 pb-10 pt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xl font-semibold",
								children: "ยืนยันออเดอร์"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setView("shop"),
								className: "min-h-11 rounded-2xl px-3 text-sm text-muted",
								children: "กลับร้าน"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-3 rounded-2xl bg-surface px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: line.product.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										baht(line.product.price),
										" × ",
										line.qty
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "ลด",
										onClick: () => setQty(line.productId, line.qty - 1),
										className: "grid size-11 place-items-center rounded-xl bg-elevated",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "เพิ่ม",
										onClick: () => setQty(line.productId, line.qty + 1),
										className: "grid size-11 place-items-center rounded-xl bg-elevated",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
									})]
								})]
							}, line.productId))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setFulfillment("DELIVERY"),
								className: `min-h-11 rounded-2xl text-sm ${fulfillment === "DELIVERY" ? "bg-primary text-primary-fg" : "bg-elevated text-muted"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "mx-auto mb-1 size-4" }), " จัดส่ง"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setFulfillment("PICKUP"),
								className: `min-h-11 rounded-2xl text-sm ${fulfillment === "PICKUP" ? "bg-primary text-primary-fg" : "bg-elevated text-muted"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, { className: "mx-auto mb-1 size-4" }), " รับที่ร้าน"]
							})]
						}),
						fulfillment === "DELIVERY" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-sm text-muted",
									htmlFor: "addr",
									children: "ที่อยู่จัดส่ง"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "addr",
									value: address,
									onChange: (e) => setAddress(e.target.value),
									rows: 3,
									className: "w-full rounded-2xl border border-line bg-surface px-3 py-2 text-base",
									placeholder: "บ้านเลขที่ ซอย ถนน แขวง เขต"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => void locate(),
										className: "min-h-11 rounded-2xl bg-elevated px-3 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mr-1 inline size-4" }), "พิกัดปัจจุบัน"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: useSamplePin,
										className: "min-h-11 rounded-2xl bg-elevated px-3 text-sm",
										children: "พิกัดใกล้ร้าน"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: lat,
										onChange: (e) => setLat(e.target.value),
										inputMode: "decimal",
										"aria-label": "ละติจูด",
										placeholder: "ละติจูด",
										className: "min-h-11 rounded-2xl border border-line bg-surface px-3 text-base"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: lng,
										onChange: (e) => setLng(e.target.value),
										inputMode: "decimal",
										"aria-label": "ลองจิจูด",
										placeholder: "ลองจิจูด",
										className: "min-h-11 rounded-2xl border border-line bg-surface px-3 text-base"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted",
									children: [geoMsg ? `${geoMsg} · ` : "", hasGeo ? `ห่าง ${distance.toFixed(2)} กม. · ค่าส่ง ${baht(quote.delivery)}` : "ยังไม่มีพิกัด จึงยังไม่คิดค่าส่ง"]
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "รับที่ร้าน ไม่มีค่าส่ง"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-4 block text-sm text-muted",
							htmlFor: "note",
							children: "โน้ตถึงร้าน"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "note",
							value: note,
							onChange: (e) => setNote(e.target.value),
							className: "mt-1 min-h-11 w-full rounded-2xl border border-line bg-surface px-3 text-base",
							placeholder: "โทรก่อนถึง / จุดสังเกต"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "โค้ดส่วนลด"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex flex-wrap gap-2",
									children: promos.filter((p) => p.active).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setPromoCode(p.code),
										className: "min-h-11 rounded-full bg-elevated px-3 text-sm",
										children: p.code
									}, p.code))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: promoCode,
									onChange: (e) => setPromoCode(e.target.value.toUpperCase()),
									className: "mt-2 min-h-11 w-full rounded-2xl border border-line bg-surface px-3 text-base uppercase",
									placeholder: "ใส่โค้ด"
								}),
								promoHint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: promoHint
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-3xl bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "แต้มที่มี" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-medium text-primary",
										children: [balance, " แต้ม"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "range",
									min: 0,
									max: Math.max(0, maxPoints),
									value: Math.min(points, maxPoints),
									onChange: (e) => setPoints(Number(e.target.value)),
									className: "mt-3 w-full",
									"aria-label": "แต้มที่ใช้แลกส่วนลด"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted",
									children: [
										"ใช้ ",
										Math.min(points, maxPoints),
										" แต้ม = ลด ",
										baht(quote.pointsOff),
										" · ออเดอร์นี้ได้เพิ่ม ",
										quote.pointsEarned,
										" แต้ม"
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setPay("CASH"),
								className: `min-h-11 rounded-2xl text-sm ${pay === "CASH" ? "bg-primary text-primary-fg" : "bg-elevated text-muted"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, { className: "mx-auto mb-1 size-4" }), " เงินสด"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setPay("TRANSFER"),
								className: `min-h-11 rounded-2xl text-sm ${pay === "TRANSFER" ? "bg-primary text-primary-fg" : "bg-elevated text-muted"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "mx-auto mb-1 size-4" }), " โอนพร้อมเพย์"]
							})]
						}),
						pay === "TRANSFER" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-3xl bg-fg p-4 text-bg",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mx-auto w-fit rounded-2xl bg-fg p-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptQr, { payload })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-center text-sm",
									children: [
										"สแกนจ่าย ",
										baht(quote.total),
										" · ",
										settings.promptPayId
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-center text-xs opacity-70",
									children: "คิวอาร์แบบไดนามิก ยอดถูกใส่ในโค้ดแล้ว"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-3 flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-2xl bg-primary text-sm font-medium text-primary-fg",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }),
										" ",
										slip ? "เปลี่ยนสลิป" : "อัปโหลดสลิป",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "file",
											accept: "image/*",
											className: "sr-only",
											onChange: (e) => void onSlip(e.target.files?.[0])
										})
									]
								}),
								slip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: slip,
									alt: "สลิปที่อัปโหลด",
									className: "mx-auto mt-3 max-h-48 rounded-2xl"
								}) : null
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 space-y-1 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "สินค้า"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: baht(subTotal) })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "ส่วนลด"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: ["-", baht(quote.discount)] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "ค่าส่ง"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: baht(quote.delivery) })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between text-base font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "ยอดสุทธิ" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-primary",
										children: baht(quote.total)
									})]
								})
							]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-danger",
							role: "alert",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: busy || count === 0,
							onClick: submit,
							className: "mt-4 min-h-12 w-full rounded-2xl bg-primary font-medium text-primary-fg disabled:opacity-40",
							children: "ยืนยันสั่งซื้อ"
						})
					]
				})
			}) : null,
			view === "done" && done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "fixed inset-0 z-30 grid place-items-center overflow-y-auto bg-bg px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-3xl bg-surface p-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto mb-3 grid size-14 place-items-center rounded-2xl bg-primary text-primary-fg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { className: "size-7" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-semibold",
							children: "รับออเดอร์แล้ว"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: done.orderId
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-3xl font-semibold text-primary",
							children: baht(done.total)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: [
								"สถานะรอดำเนินการ · ได้ ",
								done.pointsEarned,
								" แต้ม · คงเหลือ ",
								customers.find((c) => c.lineUserId === done.lineUserId)?.points ?? 0,
								" แต้ม"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setView("shop"),
							className: "mt-6 min-h-11 w-full rounded-2xl bg-primary font-medium text-primary-fg",
							children: "กลับไปเลือกสินค้า"
						})
					]
				})
			}) : null
		]
	});
}
function usePosReady() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let on = true;
		const finish = () => {
			if (on) setReady(true);
		};
		const pending = usePos.persist.rehydrate();
		if (pending && typeof pending.then === "function") pending.then(finish, finish);
		else finish();
		const onStorage = (event) => {
			if (event.key === "bai-khiao-pos") usePos.persist.rehydrate();
		};
		window.addEventListener("storage", onStorage);
		return () => {
			on = false;
			window.removeEventListener("storage", onStorage);
		};
	}, []);
	return ready;
}
//#endregion
export { todayBangkok as a, formatWhen as i, Storefront as n, usePos as o, baht as r, usePosReady as s, BootScreen as t };
