import { createFileRoute } from "@tanstack/react-router";
import { BootScreen, Storefront } from "@/components/pos/storefront";
import { usePosReady } from "@/lib/pos/ready";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const ready = usePosReady();
  if (!ready) return <BootScreen />;
  return <Storefront />;
}
