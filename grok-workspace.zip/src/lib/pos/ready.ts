import { useEffect, useState } from "react";
import { usePos } from "@/lib/pos/store";

export function usePosReady() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let on = true;
    const finish = () => {
      if (on) setReady(true);
    };
    const pending = usePos.persist.rehydrate();
    if (pending && typeof pending.then === "function") pending.then(finish, finish);
    else finish();
    const onStorage = (event: StorageEvent) => {
      if (event.key === "bai-khiao-pos") void usePos.persist.rehydrate();
    };
    window.addEventListener("storage", onStorage);
    return () => {
      on = false;
      window.removeEventListener("storage", onStorage);
    };
  }, []);
  return ready;
}
