/**
 * ใบเขียว — Kratom POS & Delivery
 * Google Apps Script backend (Sheets + Drive + LINE)
 *
 * วิธีขึ้นระบบ
 * 1) สร้าง Google Sheet → Extensions → Apps Script
 * 2) วางไฟล์นี้เป็น Code.gs และเพิ่มไฟล์ HTML ชื่อ liff กับ admin
 * 3) รัน installSystem แล้วอนุญาตสิทธิ์
 * 4) Deploy → Web app → Execute as: Me, Access: Anyone
 * 5) หน้าร้านคือ URL ของเว็บแอป, หลังบ้านต่อ ?page=admin
 * 6) ใส่ LIFF ID ใน liff.html และโทเคน LINE ในชีต Settings
 *
 * สูตร PromptPay / Haversine / แต้ม ต้องตรงกับ src/lib/pos/calc.ts
 * ตรวจ PromptPay แล้วว่าตรงกับไลบรารี promptpay-qr ทุกเคสทดสอบ
 */

var HEADERS = {
  Products: ["id", "name", "price", "recipeType", "status", "imageUrl"],
  Orders: ["orderId", "timestamp", "lineUserId", "customerName", "items", "subTotal", "discount", "deliveryFee", "total", "paymentMethod", "slipUrl", "lat", "lng", "distance", "address", "status", "note"],
  Customers: ["lineUserId", "name", "points", "totalSpent", "lastOrderDate"],
  Settings: ["key", "value"],
  Promotions: ["code", "type", "value", "minSpend", "active"],
  Stock_Logs: ["id", "productId", "productName", "type", "qty", "balance", "timestamp", "note"]
};

var SETTING_KEYS = ["shopName", "shopPhone", "promptPayId", "shopLat", "shopLng", "feeBase", "feePerKm", "pointsRate", "pointValue", "lineChannelToken", "lineAdminUserId", "adminPin"];

var DEFAULTS = {
  shopName: "ใบเขียว",
  shopPhone: "02-000-0000",
  promptPayId: "0899999991",
  shopLat: "13.7563",
  shopLng: "100.5018",
  feeBase: "25",
  feePerKm: "8",
  pointsRate: "50",
  pointValue: "1",
  lineChannelToken: "",
  lineAdminUserId: "",
  adminPin: "2580"
};

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("ใบเขียว POS")
    .addItem("ติดตั้ง / ซ่อมหัวตาราง", "installSystem")
    .addToUi();
}

/** สร้างชีต หัวตาราง และข้อมูลตั้งต้น รันครั้งแรกจากตัวแก้ไขสคริปต์ */
function installSystem() {
  var ss = getOrCreateSs_();
  Object.keys(HEADERS).forEach(function (name) {
    var sh = ss.getSheetByName(name);
    if (!sh) sh = ss.insertSheet(name);
    if (sh.getLastRow() === 0) {
      sh.appendRow(HEADERS[name]);
      sh.setFrozenRows(1);
      sh.getRange(1, 1, 1, HEADERS[name].length)
        .setFontWeight("bold")
        .setBackground("#10b981")
        .setFontColor("#042f1e");
    } else {
      var current = sh.getRange(1, 1, 1, HEADERS[name].length).getValues()[0].map(String);
      var same = HEADERS[name].every(function (h, i) { return current[i] === h; });
      if (!same && sh.getLastRow() === 1) {
        sh.getRange(1, 1, 1, HEADERS[name].length).setValues([HEADERS[name]]);
      }
    }
  });
  var settings = ss.getSheetByName("Settings");
  settings.getRange("A:B").setNumberFormat("@");
  var have = {};
  readObjects_("Settings").forEach(function (row) { have[String(row.key)] = true; });
  SETTING_KEYS.forEach(function (key) {
    if (!have[key]) settings.appendRow([key, DEFAULTS[key]]);
  });
  seedCatalog_();
  var leftover = ss.getSheetByName("Sheet1") || ss.getSheetByName("ชีต1");
  if (leftover && ss.getSheets().length > 1 && leftover.getLastRow() === 0) ss.deleteSheet(leftover);
  try {
    SpreadsheetApp.getUi().alert("ติดตั้งใบเขียวแล้ว\n" + ss.getUrl());
  } catch (err) {}
  return ss.getUrl();
}

function doGet(e) {
  var params = (e && e.parameter) || {};
  try {
    if (String(params.page || "").toLowerCase() === "admin") return htmlPage_("admin", "ใบเขียว · หลังบ้าน");
    if (params.action) return jsonOut_(route_(String(params.action), params));
    return htmlPage_("liff", "ใบเขียว");
  } catch (err) {
    return jsonOut_({ ok: false, error: String(err && err.message ? err.message : err) });
  }
}

function doPost(e) {
  var payload = {};
  try {
    payload = JSON.parse((e && e.postData && e.postData.contents) || "{}");
  } catch (err) {
    payload = (e && e.parameter) || {};
  }
  var action = payload.action || (e && e.parameter && e.parameter.action) || "";
  return jsonOut_(route_(String(action), payload));
}

/** จุดที่หน้า HTML เรียกผ่าน google.script.run.handleClient */
function handleClient(action, payload) {
  return route_(String(action || ""), payload || {});
}

function route_(action, payload) {
  try {
    return { ok: true, data: dispatch_(action, payload || {}) };
  } catch (err) {
    return { ok: false, error: String(err && err.message ? err.message : err) };
  }
}

function dispatch_(action, payload) {
  switch (action) {
    case "GET_ALL_DATA":
      if (payload.adminPin) {
        assertAdmin_(payload);
        return adminBoot_();
      }
      return publicBoot_(payload);
    case "GET_STOCK":
      assertAdmin_(payload);
      return { stock: stockMap_(), logs: recentLogs_() };
    case "GET_SETTINGS":
      assertAdmin_(payload);
      return getSettingsMap_();
    case "LIFF_CREATE_ORDER":
      return withLock_(function () { return createOrder_(payload); });
    case "ADMIN_UPDATE_ORDER":
      assertAdmin_(payload);
      return withLock_(function () { return updateOrder_(payload); });
    case "ADMIN_SAVE_PRODUCT":
      assertAdmin_(payload);
      return withLock_(function () { return saveProduct_(payload); });
    case "ADMIN_DELETE_PRODUCT":
      assertAdmin_(payload);
      return withLock_(function () { return deleteProduct_(payload); });
    case "ADMIN_SAVE_SETTINGS":
      assertAdmin_(payload);
      return withLock_(function () { return saveSettings_(payload); });
    case "ADMIN_ADJUST_STOCK":
      assertAdmin_(payload);
      return withLock_(function () { return adjustStock_(payload); });
    case "ADMIN_SAVE_PROMO":
      assertAdmin_(payload);
      return withLock_(function () { return savePromo_(payload); });
    case "ADMIN_DELETE_PROMO":
      assertAdmin_(payload);
      return withLock_(function () { return deletePromo_(payload); });
    case "ADMIN_ADJUST_POINTS":
      assertAdmin_(payload);
      return withLock_(function () { return adjustPoints_(payload); });
    case "UPLOAD_SLIP":
      return { url: uploadSlip_(payload.image || payload.slipBase64 || payload.base64, payload.orderId || "slip") };
    default:
      throw new Error("ไม่รู้จัก action: " + action);
  }
}

function publicBoot_(payload) {
  var uid = String(payload.lineUserId || "");
  return {
    products: productsWithStock_().filter(function (p) { return p.status === "ACTIVE"; }),
    settings: publicSettings_(),
    promos: readPromos_().filter(function (p) { return p.active; }),
    customer: uid ? findCustomer_(uid) : null
  };
}

function adminBoot_() {
  return {
    products: productsWithStock_(),
    orders: readOrders_(),
    customers: readObjects_("Customers").map(normalizeCustomer_),
    settings: getSettingsMap_(),
    promos: readPromos_(),
    stockLogs: recentLogs_(),
    stock: stockMap_()
  };
}

function createOrder_(payload) {
  var uid = String(payload.lineUserId || "").trim();
  var name = String(payload.customerName || "").trim();
  if (!uid || !name) throw new Error("ไม่มีข้อมูลลูกค้า");
  var rawItems = payload.items || [];
  if (!rawItems.length) throw new Error("ไม่มีสินค้าในออเดอร์");
  if (rawItems.length > 30) throw new Error("รายการยาวเกินไป");
  var catalog = productsWithStock_();
  var byId = {};
  catalog.forEach(function (p) { byId[p.id] = p; });
  var lines = [];
  var subTotal = 0;
  rawItems.forEach(function (row) {
    var qty = Math.floor(num_(row.qty));
    if (qty <= 0 || qty > 99) throw new Error("จำนวนสินค้าไม่ถูกต้อง");
    var product = byId[String(row.productId || "")];
    if (!product || product.status !== "ACTIVE") throw new Error("มีสินค้าที่ปิดขาย");
    if (qty > product.stock) throw new Error(product.name + " เหลือไม่พอ");
    lines.push({ productId: product.id, name: product.name, price: product.price, qty: qty });
    subTotal += product.price * qty;
  });
  var settings = getSettingsMap_();
  var fulfillment = String(payload.fulfillment || "DELIVERY").toUpperCase() === "PICKUP" ? "PICKUP" : "DELIVERY";
  var address = String(payload.address || "").trim();
  var lat = numOrNull_(payload.lat);
  var lng = numOrNull_(payload.lng);
  var distance = 0;
  if (fulfillment === "DELIVERY") {
    if (!address) throw new Error("กรอกที่อยู่จัดส่ง");
    if (lat == null || lng == null) throw new Error("ไม่มีพิกัดจัดส่ง");
    distance = haversineKm_(num_(settings.shopLat), num_(settings.shopLng), lat, lng);
  } else {
    address = address || "รับที่ร้าน";
    lat = null;
    lng = null;
  }
  var pay = String(payload.paymentMethod || "CASH").toUpperCase() === "TRANSFER" ? "TRANSFER" : "CASH";
  var code = String(payload.promoCode || "").trim().toUpperCase();
  var promo = null;
  if (code) {
    readPromos_().forEach(function (p) { if (p.code === code) promo = p; });
    if (!promo || !promo.active) throw new Error("โค้ดส่วนลดใช้ไม่ได้");
    if (subTotal < promo.minSpend) throw new Error("โค้ดนี้ใช้เมื่อซื้อครบ " + promo.minSpend + " บาท");
  }
  var customer = findCustomer_(uid);
  var quote = quote_({
    subTotal: subTotal,
    promo: promo,
    pointsRequested: num_(payload.pointsRequested),
    pointsBalance: customer ? customer.points : 0,
    pointValue: num_(settings.pointValue) || 1,
    pointsRate: num_(settings.pointsRate),
    distanceKm: distance,
    feeBase: num_(settings.feeBase),
    feePerKm: num_(settings.feePerKm),
    fulfillment: fulfillment
  });
  if (payload.expectTotal != null && payload.expectTotal !== "" && Math.abs(num_(payload.expectTotal) - quote.total) > 1) {
    throw new Error("ยอดเปลี่ยนเป็น " + quote.total + " บาท กรุณาตรวจอีกครั้ง");
  }
  var slipUrl = "";
  if (pay === "TRANSFER") {
    if (payload.slipBase64) slipUrl = uploadSlip_(payload.slipBase64, "order");
    else if (payload.slipUrl) slipUrl = String(payload.slipUrl);
    if (!slipUrl) throw new Error("อัปโหลดสลิปก่อนยืนยันการโอน");
  }
  var now = new Date().toISOString();
  var orderId = newOrderId_();
  lines.forEach(function (line) {
    var next = byId[line.productId].stock - line.qty;
    byId[line.productId].stock = next;
    appendObject_("Stock_Logs", {
      id: "SL" + Utilities.getUuid().slice(0, 8),
      productId: line.productId,
      productName: line.name,
      type: "OUT",
      qty: line.qty,
      balance: next,
      timestamp: now,
      note: orderId
    });
  });
  var nextPoints = (customer ? customer.points : 0) - quote.pointsUsed + quote.pointsEarned;
  var nextSpent = (customer ? customer.totalSpent : 0) + quote.total;
  upsertByKey_("Customers", "lineUserId", uid, {
    lineUserId: uid,
    name: name,
    points: nextPoints,
    totalSpent: nextSpent,
    lastOrderDate: now
  });
  var orderRow = {
    orderId: orderId,
    timestamp: now,
    lineUserId: uid,
    customerName: name,
    items: JSON.stringify({
      lines: lines,
      pointsUsed: quote.pointsUsed,
      pointsEarned: quote.pointsEarned,
      promoCode: promo ? promo.code : "",
      fulfillment: fulfillment
    }),
    subTotal: subTotal,
    discount: quote.discount,
    deliveryFee: quote.delivery,
    total: quote.total,
    paymentMethod: pay,
    slipUrl: slipUrl,
    lat: lat == null ? "" : lat,
    lng: lng == null ? "" : lng,
    distance: Math.round(distance * 100) / 100,
    address: address,
    status: "PENDING",
    note: String(payload.note || "").slice(0, 500)
  };
  appendObject_("Orders", orderRow);
  var summary = lines.map(function (l) { return "• " + l.name + " x" + l.qty; }).join("\n");
  pushLine_(settings.lineAdminUserId, [
    "ออเดอร์ใหม่ " + orderId,
    name,
    summary,
    "ยอด " + quote.total + " บาท",
    pay === "TRANSFER" ? "โอนเงิน" : "เงินสด",
    address
  ].join("\n"));
  return {
    order: parseOrderRow_(orderRow),
    customer: { lineUserId: uid, name: name, points: nextPoints, totalSpent: nextSpent, lastOrderDate: now }
  };
}

function updateOrder_(payload) {
  var orderId = String(payload.orderId || "");
  var status = String(payload.status || "").toUpperCase();
  var allowedNext = { PENDING: ["DELIVERING", "CANCELLED"], DELIVERING: ["COMPLETED", "CANCELLED"], COMPLETED: [], CANCELLED: [] };
  var orders = readObjects_("Orders");
  var current = null;
  orders.forEach(function (row) { if (String(row.orderId) === orderId) current = row; });
  if (!current) throw new Error("ไม่พบออเดอร์");
  var prev = String(current.status || "PENDING");
  if (allowedNext[prev].indexOf(status) === -1) throw new Error("เปลี่ยนสถานะนี้ไม่ได้");
  var parsed = parseOrderRow_(current);
  if (status === "CANCELLED") {
    var now = new Date().toISOString();
    var stock = stockMap_();
    parsed.items.forEach(function (line) {
      var balance = (stock[line.productId] || 0) + line.qty;
      stock[line.productId] = balance;
      appendObject_("Stock_Logs", {
        id: "SL" + Utilities.getUuid().slice(0, 8),
        productId: line.productId,
        productName: line.name,
        type: "IN",
        qty: line.qty,
        balance: balance,
        timestamp: now,
        note: "คืนสต๊อก " + orderId
      });
    });
    var customer = findCustomer_(parsed.lineUserId);
    if (customer) {
      upsertByKey_("Customers", "lineUserId", customer.lineUserId, {
        lineUserId: customer.lineUserId,
        name: customer.name,
        points: Math.max(0, customer.points + parsed.pointsUsed - parsed.pointsEarned),
        totalSpent: Math.max(0, customer.totalSpent - parsed.total),
        lastOrderDate: customer.lastOrderDate
      });
    }
  }
  current.status = status;
  upsertByKey_("Orders", "orderId", orderId, current);
  var label = { PENDING: "รอดำเนินการ", DELIVERING: "กำลังจัดส่ง", COMPLETED: "สำเร็จ", CANCELLED: "ยกเลิก" };
  pushLine_(parsed.lineUserId, "ออเดอร์ " + orderId + " อัปเดตเป็น: " + (label[status] || status));
  return parseOrderRow_(current);
}

function saveProduct_(payload) {
  var id = String(payload.id || "").trim() || ("P" + Utilities.getUuid().slice(0, 6).toUpperCase());
  var name = String(payload.name || "").trim();
  if (!name) throw new Error("ใส่ชื่อสินค้า");
  var price = Math.max(0, Math.round(num_(payload.price)));
  var exists = productsWithStock_().some(function (p) { return p.id === id; });
  upsertByKey_("Products", "id", id, {
    id: id,
    name: name,
    price: price,
    recipeType: String(payload.recipeType || "ใบแห้ง"),
    status: String(payload.status || "ACTIVE").toUpperCase() === "INACTIVE" ? "INACTIVE" : "ACTIVE",
    imageUrl: String(payload.imageUrl || "")
  });
  if (!exists) {
    var qty = Math.max(0, Math.floor(num_(payload.initialStock)));
    appendObject_("Stock_Logs", {
      id: "SL" + Utilities.getUuid().slice(0, 8),
      productId: id,
      productName: name,
      type: "IN",
      qty: qty,
      balance: qty,
      timestamp: new Date().toISOString(),
      note: "เปิดสินค้าใหม่"
    });
  }
  return productsWithStock_().filter(function (p) { return p.id === id; })[0];
}

function deleteProduct_(payload) {
  var id = String(payload.id || "");
  if (!id) throw new Error("ไม่มีรหัสสินค้า");
  deleteByKey_("Products", "id", id);
  return { id: id };
}

function adjustStock_(payload) {
  var id = String(payload.productId || "");
  var type = String(payload.type || "").toUpperCase() === "OUT" ? "OUT" : "IN";
  var qty = Math.floor(num_(payload.qty));
  if (!id || qty <= 0) throw new Error("ข้อมูลสต๊อกไม่ครบ");
  var product = null;
  productsWithStock_().forEach(function (p) { if (p.id === id) product = p; });
  if (!product) throw new Error("ไม่พบสินค้า");
  var balance = type === "IN" ? product.stock + qty : product.stock - qty;
  if (balance < 0) throw new Error("สต๊อกไม่พอให้ตัด");
  appendObject_("Stock_Logs", {
    id: "SL" + Utilities.getUuid().slice(0, 8),
    productId: id,
    productName: product.name,
    type: type,
    qty: qty,
    balance: balance,
    timestamp: new Date().toISOString(),
    note: String(payload.note || (type === "IN" ? "รับเข้า" : "ตัดออก")).slice(0, 300)
  });
  return { productId: id, balance: balance };
}

function saveSettings_(payload) {
  var incoming = payload.values || payload.settings || payload;
  var map = getSettingsMap_();
  SETTING_KEYS.forEach(function (key) {
    if (incoming[key] != null) map[key] = incoming[key];
  });
  if (!String(map.shopName || "").trim()) throw new Error("ใส่ชื่อร้าน");
  ["feeBase", "feePerKm"].forEach(function (key) {
    if (num_(map[key]) < 0) throw new Error("ค่าส่งติดลบไม่ได้");
  });
  if (num_(map.pointsRate) < 1) throw new Error("อัตราแต้มต้องอย่างน้อย 1");
  if (num_(map.pointValue) <= 0) throw new Error("มูลค่าแต้มต้องมากกว่า 0");
  var sh = getSheet_("Settings");
  var rows = SETTING_KEYS.map(function (key) { return [key, String(map[key] == null ? "" : map[key])]; });
  if (sh.getLastRow() > 1) sh.getRange(2, 1, sh.getLastRow() - 1, 2).clearContent();
  sh.getRange(2, 1, rows.length, 2).setNumberFormat("@").setValues(rows);
  return getSettingsMap_();
}

function savePromo_(payload) {
  var code = String(payload.code || "").trim().toUpperCase();
  if (!code) throw new Error("ใส่โค้ด");
  var type = String(payload.type || "FIXED").toUpperCase() === "PERCENT" ? "PERCENT" : "FIXED";
  upsertByKey_("Promotions", "code", code, {
    code: code,
    type: type,
    value: num_(payload.value),
    minSpend: num_(payload.minSpend),
    active: bool_(payload.active)
  });
  return readPromos_();
}

function deletePromo_(payload) {
  deleteByKey_("Promotions", "code", String(payload.code || "").toUpperCase());
  return readPromos_();
}

function adjustPoints_(payload) {
  var uid = String(payload.lineUserId || "");
  var customer = findCustomer_(uid);
  if (!customer) throw new Error("ไม่พบลูกค้า");
  var points = Math.max(0, Math.round(customer.points + num_(payload.delta)));
  upsertByKey_("Customers", "lineUserId", uid, {
    lineUserId: uid,
    name: customer.name,
    points: points,
    totalSpent: customer.totalSpent,
    lastOrderDate: customer.lastOrderDate
  });
  return { lineUserId: uid, points: points };
}

function uploadSlip_(dataUrl, name) {
  var blob = decodeSlip_(dataUrl, name);
  var folder = getSlipFolder_();
  var file = folder.createFile(blob);
  try {
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  } catch (err) {}
  return "https://drive.google.com/uc?export=view&id=" + file.getId();
}

function pushLine_(to, text) {
  try {
    var settings = getSettingsMap_();
    var token = String(settings.lineChannelToken || "").trim();
    var user = String(to || "").trim();
    if (!token || !user || user.indexOf("LOCAL-") === 0 || user.indexOf("DEMO") === 0) return;
    var res = UrlFetchApp.fetch("https://api.line.me/v2/bot/message/push", {
      method: "post",
      contentType: "application/json",
      headers: { Authorization: "Bearer " + token },
      payload: JSON.stringify({ to: user, messages: [{ type: "text", text: String(text).slice(0, 4900) }] }),
      muteHttpExceptions: true
    });
    if (res.getResponseCode() >= 300) console.error("LINE", res.getResponseCode(), res.getContentText());
  } catch (err) {
    console.error("LINE push failed", err);
  }
}

function quote_(input) {
  var promoOff = 0;
  if (input.promo && input.promo.active && input.subTotal + 1e-9 >= input.promo.minSpend) {
    promoOff = input.promo.type === "PERCENT"
      ? Math.min(input.subTotal, Math.floor((input.subTotal * num_(input.promo.value)) / 100))
      : Math.min(input.subTotal, Math.round(num_(input.promo.value)));
  }
  var afterPromo = Math.max(0, input.subTotal - promoOff);
  var pointValue = Math.max(0.01, num_(input.pointValue) || 1);
  var maxByMoney = Math.floor(afterPromo / pointValue);
  var pointsUsed = Math.max(0, Math.min(Math.floor(num_(input.pointsRequested)), Math.floor(num_(input.pointsBalance)), maxByMoney));
  var pointsOff = Math.min(afterPromo, pointsUsed * pointValue);
  var discount = promoOff + pointsOff;
  var delivery = input.fulfillment === "PICKUP" ? 0 : deliveryFee_(input.distanceKm, input.feeBase, input.feePerKm);
  var netGoods = Math.max(0, input.subTotal - discount);
  var rate = num_(input.pointsRate);
  var pointsEarned = rate > 0 ? Math.floor(netGoods / rate) : 0;
  return { promoOff: promoOff, pointsUsed: pointsUsed, pointsOff: pointsOff, discount: discount, delivery: delivery, pointsEarned: pointsEarned, total: netGoods + delivery };
}

function deliveryFee_(km, feeBase, feePerKm) {
  if (!isFinite(km) || km < 0) return 0;
  return Math.max(0, Math.ceil(num_(feeBase) + km * num_(feePerKm)));
}

function haversineKm_(lat1, lng1, lat2, lng2) {
  var R = 6371;
  var rad = Math.PI / 180;
  var dLat = (lat2 - lat1) * rad;
  var dLng = (lng2 - lng1) * rad;
  var a = Math.pow(Math.sin(dLat / 2), 2) + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.pow(Math.sin(dLng / 2), 2);
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(Math.max(0, a))));
}

function assertAdmin_(payload) {
  var pin = String(getSettingsMap_().adminPin || "");
  if (!pin) return;
  if (String(payload.adminPin || "") !== pin) throw new Error("รหัสแอดมินไม่ถูกต้อง");
}

function publicSettings_() {
  var all = getSettingsMap_();
  return {
    shopName: all.shopName,
    shopPhone: all.shopPhone,
    promptPayId: String(all.promptPayId || ""),
    shopLat: num_(all.shopLat),
    shopLng: num_(all.shopLng),
    feeBase: num_(all.feeBase),
    feePerKm: num_(all.feePerKm),
    pointsRate: num_(all.pointsRate),
    pointValue: num_(all.pointValue) || 1
  };
}

function getSettingsMap_() {
  var map = {};
  SETTING_KEYS.forEach(function (key) { map[key] = DEFAULTS[key]; });
  readObjects_("Settings").forEach(function (row) {
    if (row.key) map[String(row.key)] = row.value;
  });
  return map;
}

function productsWithStock_() {
  var stock = stockMap_();
  return readObjects_("Products").filter(function (p) { return p.id; }).map(function (p) {
    return {
      id: String(p.id),
      name: String(p.name || ""),
      price: num_(p.price),
      recipeType: String(p.recipeType || ""),
      status: String(p.status || "ACTIVE"),
      imageUrl: String(p.imageUrl || ""),
      stock: stock[String(p.id)] || 0
    };
  });
}

function stockMap_() {
  var map = {};
  readObjects_("Stock_Logs").forEach(function (row) {
    if (row.productId) map[String(row.productId)] = num_(row.balance);
  });
  return map;
}

function recentLogs_() {
  return readObjects_("Stock_Logs").slice(-200).reverse().map(function (row) {
    return {
      id: String(row.id || ""),
      productId: String(row.productId || ""),
      productName: String(row.productName || ""),
      type: String(row.type || ""),
      qty: num_(row.qty),
      balance: num_(row.balance),
      timestamp: String(row.timestamp || ""),
      note: String(row.note || "")
    };
  });
}

function readPromos_() {
  return readObjects_("Promotions").filter(function (p) { return p.code; }).map(function (p) {
    return {
      code: String(p.code).toUpperCase(),
      type: String(p.type).toUpperCase() === "PERCENT" ? "PERCENT" : "FIXED",
      value: num_(p.value),
      minSpend: num_(p.minSpend),
      active: bool_(p.active)
    };
  });
}

function readOrders_() {
  return readObjects_("Orders").map(parseOrderRow_).reverse();
}

function parseOrderRow_(row) {
  var meta = { lines: [], pointsUsed: 0, pointsEarned: 0, promoCode: "", fulfillment: "DELIVERY" };
  try {
    var raw = JSON.parse(row.items || "{}");
    if (Array.isArray(raw)) meta.lines = raw;
    else {
      meta.lines = raw.lines || [];
      meta.pointsUsed = num_(raw.pointsUsed);
      meta.pointsEarned = num_(raw.pointsEarned);
      meta.promoCode = raw.promoCode || "";
      meta.fulfillment = raw.fulfillment || "DELIVERY";
    }
  } catch (err) {}
  return {
    orderId: String(row.orderId || ""),
    timestamp: String(row.timestamp || ""),
    lineUserId: String(row.lineUserId || ""),
    customerName: String(row.customerName || ""),
    items: meta.lines,
    pointsUsed: meta.pointsUsed,
    pointsEarned: meta.pointsEarned,
    promoCode: meta.promoCode,
    fulfillment: meta.fulfillment,
    subTotal: num_(row.subTotal),
    discount: num_(row.discount),
    deliveryFee: num_(row.deliveryFee),
    total: num_(row.total),
    paymentMethod: String(row.paymentMethod || ""),
    slipUrl: String(row.slipUrl || ""),
    lat: row.lat === "" || row.lat == null ? null : num_(row.lat),
    lng: row.lng === "" || row.lng == null ? null : num_(row.lng),
    distance: num_(row.distance),
    address: String(row.address || ""),
    status: String(row.status || "PENDING"),
    note: String(row.note || "")
  };
}

function findCustomer_(uid) {
  var found = null;
  readObjects_("Customers").forEach(function (row) {
    if (String(row.lineUserId) === String(uid)) found = normalizeCustomer_(row);
  });
  return found;
}

function normalizeCustomer_(row) {
  return {
    lineUserId: String(row.lineUserId || ""),
    name: String(row.name || ""),
    points: num_(row.points),
    totalSpent: num_(row.totalSpent),
    lastOrderDate: String(row.lastOrderDate || "")
  };
}

function seedCatalog_() {
  var products = getSheet_("Products");
  if (products.getLastRow() > 1) return;
  var rows = [
    ["P001", "ใบกระท่อมแดงอบแห้ง 100 กรัม", 180, "ใบแห้ง", "ACTIVE", ""],
    ["P002", "ผงกระท่อมคัดใบ 50 กรัม", 220, "ผง", "ACTIVE", ""],
    ["P003", "ชาชงใบเขียว 10 ซอง", 150, "ชา", "ACTIVE", ""],
    ["P004", "น้ำกระท่อมพร้อมดื่ม 300 มล.", 45, "เครื่องดื่ม", "ACTIVE", ""],
    ["P005", "แคปซูลใบเขียว 60 แคปซูล", 290, "แคปซูล", "ACTIVE", ""],
    ["P006", "ใบก้านทองอบแห้ง 100 กรัม", 210, "ใบแห้ง", "ACTIVE", ""]
  ];
  var opening = [40, 30, 25, 48, 20, 18];
  var now = new Date().toISOString();
  rows.forEach(function (row, i) {
    products.appendRow(row);
    appendObject_("Stock_Logs", {
      id: "SLOPEN" + (i + 1),
      productId: row[0],
      productName: row[1],
      type: "IN",
      qty: opening[i],
      balance: opening[i],
      timestamp: now,
      note: "สต๊อกเปิดร้าน"
    });
  });
  var promos = getSheet_("Promotions");
  if (promos.getLastRow() === 1) {
    promos.appendRow(["WELCOME10", "PERCENT", 10, 200, true]);
    promos.appendRow(["SAVE30", "FIXED", 30, 150, true]);
  }
}

function readObjects_(name) {
  var sh = getSheet_(name);
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var headers = values[0].map(String);
  var out = [];
  for (var r = 1; r < values.length; r++) {
    if (values[r].join("") === "") continue;
    var obj = {};
    for (var c = 0; c < headers.length; c++) obj[headers[c]] = values[r][c];
    out.push(obj);
  }
  return out;
}

function appendObject_(name, obj) {
  var sh = getSheet_(name);
  sh.appendRow(HEADERS[name].map(function (key) { return cell_(obj[key]); }));
}

function upsertByKey_(name, key, value, obj) {
  var sh = getSheet_(name);
  var headers = HEADERS[name];
  var keyIdx = headers.indexOf(key);
  var values = sh.getDataRange().getValues();
  var row = headers.map(function (h) { return cell_(obj[h]); });
  for (var i = 1; i < values.length; i++) {
    if (String(values[i][keyIdx]) === String(value)) {
      sh.getRange(i + 1, 1, 1, headers.length).setValues([row]);
      return;
    }
  }
  sh.appendRow(row);
}

function deleteByKey_(name, key, value) {
  var sh = getSheet_(name);
  var keyIdx = HEADERS[name].indexOf(key);
  var values = sh.getDataRange().getValues();
  for (var i = values.length - 1; i >= 1; i--) {
    if (String(values[i][keyIdx]) === String(value)) sh.deleteRow(i + 1);
  }
}

function cell_(value) {
  if (value == null) return "";
  if (typeof value === "string" && /^[=+\-@]/.test(value)) return "'" + value;
  return value;
}

function getSheet_(name) {
  var sh = getSS_().getSheetByName(name);
  if (!sh) throw new Error("ไม่พบชีต " + name + " — รัน installSystem");
  return sh;
}

function getSS_() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty("SPREADSHEET_ID");
  if (id) {
    try { return SpreadsheetApp.openById(id); } catch (err) {}
  }
  var active = null;
  try { active = SpreadsheetApp.getActiveSpreadsheet(); } catch (err2) {}
  if (!active) throw new Error("ยังไม่ได้ติดตั้ง — รัน installSystem");
  props.setProperty("SPREADSHEET_ID", active.getId());
  return active;
}

function getOrCreateSs_() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty("SPREADSHEET_ID");
  if (id) {
    try { return SpreadsheetApp.openById(id); } catch (err) {}
  }
  var active = null;
  try { active = SpreadsheetApp.getActiveSpreadsheet(); } catch (err2) {}
  var ss = active || SpreadsheetApp.create("Kratom POS - ใบเขียว");
  props.setProperty("SPREADSHEET_ID", ss.getId());
  return ss;
}

function getSlipFolder_() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty("SLIP_FOLDER_ID");
  if (id) {
    try { return DriveApp.getFolderById(id); } catch (err) {}
  }
  var folder = DriveApp.createFolder("Kratom POS Slips");
  try { folder.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (err2) {}
  props.setProperty("SLIP_FOLDER_ID", folder.getId());
  return folder;
}

function decodeSlip_(dataUrl) {
  var raw = String(dataUrl || "");
  var parts = raw.split(",");
  var b64 = parts.length > 1 ? parts[1] : parts[0];
  if (!b64) throw new Error("ไม่มีรูปสลิป");
  if (b64.length > 3500000) throw new Error("ไฟล์สลิปใหญ่เกินไป");
  var head = parts[0] || "";
  var mime = head.indexOf("png") !== -1 ? "image/png" : "image/jpeg";
  return Utilities.newBlob(Utilities.base64Decode(b64), mime, "slip-" + Date.now() + (mime === "image/png" ? ".png" : ".jpg"));
}

function newOrderId_() {
  var props = PropertiesService.getScriptProperties();
  var n = num_(props.getProperty("ORDER_SEQ")) + 1;
  props.setProperty("ORDER_SEQ", String(n));
  var stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || "Asia/Bangkok", "yyyyMMddHHmmss");
  return "BK" + stamp + ("00" + (n % 100)).slice(-2);
}

function withLock_(fn) {
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try { return fn(); } finally { lock.releaseLock(); }
}

function htmlPage_(file, title) {
  return HtmlService.createHtmlOutputFromFile(file)
    .setTitle(title)
    .addMetaTag("viewport", "width=device-width, initial-scale=1")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function jsonOut_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function num_(value) {
  var n = Number(value);
  return isFinite(n) ? n : 0;
}

function numOrNull_(value) {
  if (value == null || value === "") return null;
  var n = Number(value);
  return isFinite(n) ? n : null;
}

function bool_(value) {
  return value === true || String(value).toUpperCase() === "TRUE" || String(value) === "1";
}
