export type Product = {
  id: string;
  name: string;
  price: number;
  recipeType: string;
  status: "ACTIVE" | "INACTIVE";
  imageUrl: string;
  stock: number;
};

export type CartLine = { productId: string; qty: number };

export type OrderItem = {
  productId: string;
  name: string;
  price: number;
  qty: number;
};

export type OrderStatus = "PENDING" | "DELIVERING" | "COMPLETED" | "CANCELLED";
export type PayMethod = "CASH" | "TRANSFER";
export type Fulfillment = "DELIVERY" | "PICKUP";

export type Order = {
  orderId: string;
  timestamp: string;
  lineUserId: string;
  customerName: string;
  items: OrderItem[];
  subTotal: number;
  discount: number;
  pointsUsed: number;
  pointsEarned: number;
  deliveryFee: number;
  total: number;
  paymentMethod: PayMethod;
  slipUrl: string;
  lat: number | null;
  lng: number | null;
  distance: number;
  address: string;
  fulfillment: Fulfillment;
  status: OrderStatus;
  note: string;
  promoCode: string;
};

export type Customer = {
  lineUserId: string;
  name: string;
  points: number;
  totalSpent: number;
  lastOrderDate: string;
};

export type Settings = {
  shopName: string;
  shopPhone: string;
  promptPayId: string;
  shopLat: number;
  shopLng: number;
  feeBase: number;
  feePerKm: number;
  pointsRate: number;
  pointValue: number;
  lineChannelToken: string;
  lineAdminUserId: string;
  adminPin: string;
};

export type Promo = {
  code: string;
  type: "PERCENT" | "FIXED";
  value: number;
  minSpend: number;
  active: boolean;
};

export type StockLog = {
  id: string;
  productId: string;
  productName: string;
  type: "IN" | "OUT";
  qty: number;
  balance: number;
  timestamp: string;
  note: string;
};

export type SessionUser = {
  lineUserId: string;
  name: string;
  pictureUrl: string;
};

export const STATUS_LABEL: Record<OrderStatus, string> = {
  PENDING: "รอดำเนินการ",
  DELIVERING: "กำลังส่ง",
  COMPLETED: "สำเร็จ",
  CANCELLED: "ยกเลิก",
};

export const RECIPE_TYPES = ["ใบแห้ง", "ผง", "ชา", "เครื่องดื่ม", "แคปซูล"] as const;
