import { createFileRoute } from "@tanstack/react-router";
import { AdminDesk } from "@/components/pos/admin-desk";
import { BootScreen } from "@/components/pos/storefront";
import { usePosReady } from "@/lib/pos/ready";

export const Route = createFileRoute("/admin")({ component: AdminPage });

function AdminPage() {
  const ready = usePosReady();
  if (!ready) return <BootScreen />;
  return <AdminDesk />;
}
