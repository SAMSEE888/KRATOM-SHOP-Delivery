import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as Leaf, s as RotateCcw } from "../_libs/lucide-react.mjs";
import { a as todayBangkok, i as formatWhen, o as usePos, r as baht, s as usePosReady, t as BootScreen } from "./ready-BfabTftk.mjs";
import { a as ResponsiveContainer, i as Area, n as YAxis, o as Tooltip, r as XAxis, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-GupqYPoI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS_LABEL = {
	PENDING: "รอดำเนินการ",
	DELIVERING: "กำลังส่ง",
	COMPLETED: "สำเร็จ",
	CANCELLED: "ยกเลิก"
};
var RECIPE_TYPES = [
	"ใบแห้ง",
	"ผง",
	"ชา",
	"เครื่องดื่ม",
	"แคปซูล"
];
var TABS = [
	["home", "ภาพรวม"],
	["orders", "ออเดอร์"],
	["products", "สินค้า"],
	["customers", "ลูกค้า"],
	["settings", "ตั้งค่า"],
	["deploy", "ขึ้นระบบ"]
];
function blankProduct() {
	return {
		id: "P" + Date.now().toString(36).toUpperCase(),
		name: "",
		price: 0,
		recipeType: "ใบแห้ง",
		status: "ACTIVE",
		imageUrl: "",
		stock: 0
	};
}
function AdminDesk() {
	const settings = usePos((s) => s.settings);
	const orders = usePos((s) => s.orders);
	const products = usePos((s) => s.products);
	const customers = usePos((s) => s.customers);
	const promos = usePos((s) => s.promos);
	const stockLogs = usePos((s) => s.stockLogs);
	const updateOrderStatus = usePos((s) => s.updateOrderStatus);
	const saveProduct = usePos((s) => s.saveProduct);
	const deleteProduct = usePos((s) => s.deleteProduct);
	const adjustStock = usePos((s) => s.adjustStock);
	const saveSettings = usePos((s) => s.saveSettings);
	const savePromo = usePos((s) => s.savePromo);
	const deletePromo = usePos((s) => s.deletePromo);
	const adjustPoints = usePos((s) => s.adjustPoints);
	const resetDemo = usePos((s) => s.resetDemo);
	const [tab, setTab] = (0, import_react.useState)("home");
	const [unlocked, setUnlocked] = (0, import_react.useState)(false);
	const [pin, setPin] = (0, import_react.useState)("");
	const [pinError, setPinError] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("ALL");
	const [query, setQuery] = (0, import_react.useState)("");
	const [slip, setSlip] = (0, import_react.useState)("");
	const [creating, setCreating] = (0, import_react.useState)(true);
	const [draft, setDraft] = (0, import_react.useState)(blankProduct);
	const [stockTarget, setStockTarget] = (0, import_react.useState)("");
	const [initialStock, setInitialStock] = (0, import_react.useState)("0");
	const [stockQty, setStockQty] = (0, import_react.useState)(1);
	const [stockNote, setStockNote] = (0, import_react.useState)("");
	const [form, setForm] = (0, import_react.useState)(() => settingsToForm(settings));
	const [formError, setFormError] = (0, import_react.useState)("");
	const [promo, setPromo] = (0, import_react.useState)({
		code: "",
		type: "PERCENT",
		value: 10,
		minSpend: 0,
		active: true
	});
	const [notice, setNotice] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (sessionStorage.getItem("bai-khiao-admin") === "1") setUnlocked(true);
	}, []);
	const today = todayBangkok();
	const todaySales = orders.filter((o) => o.status !== "CANCELLED").filter((o) => todayBangkok(o.timestamp) === today).reduce((sum, o) => sum + o.total, 0);
	const pending = orders.filter((o) => o.status === "PENDING").length;
	const delivering = orders.filter((o) => o.status === "DELIVERING").length;
	const chart = (0, import_react.useMemo)(() => {
		const rows = [];
		for (let i = 6; i >= 0; i--) {
			const date = /* @__PURE__ */ new Date(Date.now() - i * 864e5);
			const key = todayBangkok(date.toISOString());
			const label = new Intl.DateTimeFormat("th-TH", {
				timeZone: "Asia/Bangkok",
				day: "numeric",
				month: "short"
			}).format(date);
			const total = orders.filter((o) => o.status !== "CANCELLED" && todayBangkok(o.timestamp) === key).reduce((sum, o) => sum + o.total, 0);
			rows.push({
				day: label,
				total
			});
		}
		return rows;
	}, [orders]);
	const filtered = orders.filter((o) => {
		if (status !== "ALL" && o.status !== status) return false;
		const q = query.trim().toLowerCase();
		if (!q) return true;
		return o.orderId.toLowerCase().includes(q) || o.customerName.toLowerCase().includes(q) || o.address.toLowerCase().includes(q);
	});
	function unlock() {
		if (pin.trim() === settings.adminPin) {
			sessionStorage.setItem("bai-khiao-admin", "1");
			setUnlocked(true);
			setPinError("");
			return;
		}
		setPinError("รหัสไม่ถูกต้อง");
	}
	function act(orderId, next) {
		const error = updateOrderStatus(orderId, next);
		setNotice(error || `อัปเดต ${orderId} เป็น ${STATUS_LABEL[next]}`);
	}
	function saveDraft() {
		if (!draft.name.trim()) {
			setNotice("ใส่ชื่อสินค้า");
			return;
		}
		saveProduct({
			...draft,
			name: draft.name.trim(),
			price: Number(draft.price) || 0
		}, creating ? Number(initialStock) || 0 : void 0);
		setNotice("บันทึกสินค้าแล้ว");
		setCreating(false);
	}
	function onSaveSettings() {
		if (!form.shopName.trim()) {
			setFormError("ใส่ชื่อร้าน");
			return;
		}
		const shopLat = Number(form.shopLat);
		const shopLng = Number(form.shopLng);
		if (!Number.isFinite(shopLat) || !Number.isFinite(shopLng)) {
			setFormError("พิกัดร้านไม่ถูกต้อง");
			return;
		}
		if (Number(form.pointsRate) < 1 || Number(form.pointValue) <= 0) {
			setFormError("อัตราแต้มต้องมากกว่า 0");
			return;
		}
		saveSettings({
			shopName: form.shopName.trim(),
			shopPhone: form.shopPhone.trim(),
			promptPayId: form.promptPayId.replace(/\s/g, ""),
			shopLat,
			shopLng,
			feeBase: Math.max(0, Number(form.feeBase) || 0),
			feePerKm: Math.max(0, Number(form.feePerKm) || 0),
			pointsRate: Math.max(1, Number(form.pointsRate) || 1),
			pointValue: Math.max(.01, Number(form.pointValue) || 1),
			lineChannelToken: form.lineChannelToken.trim(),
			lineAdminUserId: form.lineAdminUserId.trim(),
			adminPin: form.adminPin.trim() || "2580"
		});
		setFormError("");
		setNotice("บันทึกการตั้งค่าแล้ว");
	}
	if (!unlocked) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center px-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "glass w-full max-w-sm rounded-3xl p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-4 grid size-12 place-items-center rounded-2xl bg-primary text-primary-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { className: "size-6" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold",
					children: "หลังบ้านใบเขียว"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "รหัสเริ่มต้น 2580 เปลี่ยนได้ในตั้งค่า"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: pin,
					onChange: (e) => setPin(e.target.value),
					type: "password",
					inputMode: "numeric",
					"aria-label": "รหัสแอดมิน",
					className: "mt-4 min-h-11 w-full rounded-2xl border border-line bg-elevated px-3 text-base"
				}),
				pinError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-danger",
					role: "alert",
					children: pinError
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: unlock,
					className: "mt-4 min-h-11 w-full rounded-2xl bg-primary font-medium text-primary-fg",
					children: "เข้าสู่ระบบ"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "mt-3 block text-center text-sm text-muted",
					children: "กลับหน้าร้าน"
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto min-h-screen max-w-6xl px-4 pb-16 pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-4 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-11 place-items-center rounded-2xl bg-primary text-primary-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl font-semibold",
						children: settings.shopName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "หลังบ้าน · ข้อมูลอยู่บนเครื่องนี้"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "min-h-11 rounded-2xl bg-elevated px-4 py-2 text-sm",
					children: "หน้าร้าน"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "no-scrollbar -mx-4 mb-4 flex gap-2 overflow-x-auto px-4",
				children: TABS.map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab(id),
					className: `min-h-11 shrink-0 rounded-full px-4 text-sm ${tab === id ? "bg-primary text-primary-fg" : "bg-elevated text-muted"}`,
					children: label
				}, id))
			}),
			notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 rounded-2xl bg-elevated px-4 py-3 text-sm",
				role: "status",
				children: notice
			}) : null,
			tab === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "ยอดขายวันนี้",
								value: baht(todaySales)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "รอดำเนินการ",
								value: String(pending)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "กำลังส่ง",
								value: String(delivering)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "ออเดอร์ทั้งหมด",
								value: String(orders.length)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl border border-line bg-surface p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-3 text-sm text-muted",
							children: "ยอดขาย 7 วัน (ไม่รวมที่ยกเลิก)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-52",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
									data: chart,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
											dataKey: "day",
											stroke: "var(--color-muted)",
											fontSize: 12,
											tickLine: false,
											axisLine: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
											stroke: "var(--color-muted)",
											fontSize: 12,
											tickLine: false,
											axisLine: false,
											width: 40
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
											formatter: (value) => baht(Number(value)),
											contentStyle: {
												background: "var(--color-elevated)",
												border: "1px solid var(--color-line)",
												borderRadius: 12,
												color: "var(--color-fg)"
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
											type: "monotone",
											dataKey: "total",
											stroke: "var(--color-primary)",
											fill: "var(--color-primary)",
											fillOpacity: .2
										})
									]
								})
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderList, {
						orders: orders.filter((o) => o.status === "PENDING" || o.status === "DELIVERING"),
						onAct: act,
						onSlip: setSlip,
						empty: "ไม่มีออเดอร์ค้าง"
					})
				]
			}) : null,
			tab === "orders" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "ค้นหาเลขที่ / ชื่อ / ที่อยู่",
					className: "min-h-11 flex-1 rounded-2xl border border-line bg-surface px-3 text-base"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: status,
					onChange: (e) => setStatus(e.target.value),
					className: "min-h-11 rounded-2xl border border-line bg-surface px-3 text-base",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "ALL",
						children: "ทุกสถานะ"
					}), Object.keys(STATUS_LABEL).map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: key,
						children: STATUS_LABEL[key]
					}, key))]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderList, {
				orders: filtered,
				onAct: act,
				onSlip: setSlip,
				empty: "ไม่พบออเดอร์"
			})] }) : null,
			tab === "products" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-[1fr_1.2fr]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "space-y-3 rounded-3xl border border-line bg-surface p-4",
						onSubmit: (e) => {
							e.preventDefault();
							saveDraft();
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-medium",
								children: creating || !products.some((p) => p.id === draft.id) ? "สินค้าใหม่" : "แก้ไขสินค้า"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "ชื่อ",
								value: draft.name,
								onChange: (v) => setDraft({
									...draft,
									name: v
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "ราคา",
								value: String(draft.price),
								onChange: (v) => setDraft({
									...draft,
									price: Number(v)
								}),
								type: "number"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm text-muted",
								children: ["ประเภท", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: draft.recipeType,
									onChange: (e) => setDraft({
										...draft,
										recipeType: e.target.value
									}),
									className: "mt-1 min-h-11 w-full rounded-2xl border border-line bg-elevated px-3 text-base",
									children: RECIPE_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: t }, t))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm text-muted",
								children: ["สถานะ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: draft.status,
									onChange: (e) => setDraft({
										...draft,
										status: e.target.value
									}),
									className: "mt-1 min-h-11 w-full rounded-2xl border border-line bg-elevated px-3 text-base",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "ACTIVE",
										children: "เปิดขาย"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "INACTIVE",
										children: "ปิดขาย"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "ลิงก์รูป",
								value: draft.imageUrl,
								onChange: (v) => setDraft({
									...draft,
									imageUrl: v
								})
							}),
							creating ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "สต๊อกเริ่มต้น",
								value: initialStock,
								onChange: setInitialStock,
								type: "number"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									"สต๊อกปัจจุบัน ",
									products.find((p) => p.id === draft.id)?.stock ?? 0,
									" — ปรับแยกด้านขวา"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									className: "min-h-11 flex-1 rounded-2xl bg-primary font-medium text-primary-fg",
									children: "บันทึก"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setCreating(true);
										setDraft(blankProduct());
										setInitialStock("0");
									},
									className: "min-h-11 rounded-2xl bg-elevated px-4 text-sm",
									children: "ใหม่"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-3xl border border-line bg-surface p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										setCreating(false);
										setDraft(p);
									},
									className: "flex w-full items-center gap-3 text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-14 overflow-hidden rounded-2xl bg-elevated",
										children: p.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: p.imageUrl,
											alt: "",
											className: "h-full w-full object-cover"
										}) : null
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate font-medium",
											children: p.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm text-muted",
											children: [
												baht(p.price),
												" · เหลือ ",
												p.stock,
												" · ",
												p.status === "ACTIVE" ? "เปิดขาย" : "ปิดขาย"
											]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex flex-wrap gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => {
											setStockNote("");
											setStockQty(1);
											setStockTarget(stockTarget === p.id ? "" : p.id);
										},
										className: "min-h-11 rounded-2xl bg-elevated px-3 text-sm",
										children: "ปรับสต๊อก"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => deleteProduct(p.id),
										className: "min-h-11 rounded-2xl px-3 text-sm text-danger",
										children: "ลบ"
									})]
								}),
								stockTarget === p.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex flex-wrap gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											min: 1,
											value: stockQty,
											onChange: (e) => setStockQty(Number(e.target.value)),
											"aria-label": "จำนวน",
											className: "min-h-11 w-24 rounded-2xl border border-line bg-elevated px-3"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: stockNote,
											onChange: (e) => setStockNote(e.target.value),
											placeholder: "โน้ต",
											className: "min-h-11 min-w-32 flex-1 rounded-2xl border border-line bg-elevated px-3"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setNotice(adjustStock(p.id, "IN", stockQty, stockNote) || "รับเข้าแล้ว"),
											className: "min-h-11 rounded-2xl bg-primary px-3 text-sm text-primary-fg",
											children: "เข้า"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setNotice(adjustStock(p.id, "OUT", stockQty, stockNote) || "ตัดออกแล้ว"),
											className: "min-h-11 rounded-2xl bg-elevated px-3 text-sm",
											children: "ออก"
										})
									]
								}) : null
							]
						}, p.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-2 text-sm text-muted",
							children: "ความเคลื่อนไหวสต๊อกล่าสุด"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-1 text-sm",
							children: stockLogs.slice(0, 12).map((log) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between gap-3 rounded-2xl bg-surface px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									log.type === "IN" ? "เข้า" : "ออก",
									" ",
									log.productName,
									" ",
									log.qty,
									" · คงเหลือ ",
									log.balance
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: log.note
								})]
							}, log.id))
						})]
					})
				]
			}) : null,
			tab === "customers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [customers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "ยังไม่มีลูกค้า — จะถูกสร้างเมื่อมีการสั่งซื้อ"
				}) : null, customers.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-3xl border border-line bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-medium",
								children: c.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: c.lineUserId
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-primary",
								children: [c.points, " แต้ม"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: [
								"ยอดสะสม ",
								baht(c.totalSpent),
								" · ล่าสุด ",
								c.lastOrderDate ? formatWhen(c.lastOrderDate) : "-"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => adjustPoints(c.lineUserId, 10),
								className: "min-h-11 rounded-2xl bg-elevated px-3 text-sm",
								children: "+10 แต้ม"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => adjustPoints(c.lineUserId, -10),
								className: "min-h-11 rounded-2xl bg-elevated px-3 text-sm",
								children: "-10 แต้ม"
							})]
						})
					]
				}, c.lineUserId))]
			}) : null,
			tab === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-3 rounded-3xl border border-line bg-surface p-4",
					onSubmit: (e) => {
						e.preventDefault();
						onSaveSettings();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "ชื่อร้าน",
							value: form.shopName,
							onChange: (v) => setForm({
								...form,
								shopName: v
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "เบอร์โทร",
							value: form.shopPhone,
							onChange: (v) => setForm({
								...form,
								shopPhone: v
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "พร้อมเพย์ (เบอร์หรือเลขผู้เสียภาษี)",
							value: form.promptPayId,
							onChange: (v) => setForm({
								...form,
								promptPayId: v
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "ละติจูดร้าน",
								value: form.shopLat,
								onChange: (v) => setForm({
									...form,
									shopLat: v
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "ลองจิจูดร้าน",
								value: form.shopLng,
								onChange: (v) => setForm({
									...form,
									shopLng: v
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "ค่าส่งเริ่มต้น (บาท)",
								value: form.feeBase,
								onChange: (v) => setForm({
									...form,
									feeBase: v
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "ค่าส่งต่อกิโลเมตร",
								value: form.feePerKm,
								onChange: (v) => setForm({
									...form,
									feePerKm: v
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "บาทต่อการได้ 1 แต้ม",
								value: form.pointsRate,
								onChange: (v) => setForm({
									...form,
									pointsRate: v
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "บาทที่ลดได้ต่อ 1 แต้ม",
								value: form.pointValue,
								onChange: (v) => setForm({
									...form,
									pointValue: v
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Channel access token (LINE)",
							value: form.lineChannelToken,
							onChange: (v) => setForm({
								...form,
								lineChannelToken: v
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "User ID แอดมิน (รับแจ้งเตือน)",
							value: form.lineAdminUserId,
							onChange: (v) => setForm({
								...form,
								lineAdminUserId: v
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "รหัสหลังบ้าน",
							value: form.adminPin,
							onChange: (v) => setForm({
								...form,
								adminPin: v
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs leading-5 text-muted",
							children: "ค่าส่ง = ปัดขึ้น(ค่าเริ่มต้น + ระยะทางกม. × ค่าต่อกม.) โทเคน LINE ใช้เมื่อต่อ Apps Script จริง"
						}),
						formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-danger",
							children: formError
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "min-h-11 w-full rounded-2xl bg-primary font-medium text-primary-fg",
							children: "บันทึกการตั้งค่า"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "space-y-3 rounded-3xl border border-line bg-surface p-4",
							onSubmit: (e) => {
								e.preventDefault();
								if (!promo.code.trim()) return;
								savePromo(promo);
								setNotice("บันทึกโปรโมชันแล้ว");
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-medium",
									children: "โปรโมชัน"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "โค้ด",
									value: promo.code,
									onChange: (v) => setPromo({
										...promo,
										code: v.toUpperCase()
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm text-muted",
									children: ["ชนิด", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: promo.type,
										onChange: (e) => setPromo({
											...promo,
											type: e.target.value
										}),
										className: "mt-1 min-h-11 w-full rounded-2xl border border-line bg-elevated px-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "PERCENT",
											children: "เปอร์เซ็นต์"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "FIXED",
											children: "บาท"
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "มูลค่า",
										value: String(promo.value),
										onChange: (v) => setPromo({
											...promo,
											value: Number(v)
										}),
										type: "number"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "ยอดขั้นต่ำ",
										value: String(promo.minSpend),
										onChange: (v) => setPromo({
											...promo,
											minSpend: Number(v)
										}),
										type: "number"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex min-h-11 items-center gap-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: promo.active,
										onChange: (e) => setPromo({
											...promo,
											active: e.target.checked
										})
									}), " เปิดใช้"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									className: "min-h-11 w-full rounded-2xl bg-primary font-medium text-primary-fg",
									children: "บันทึกโค้ด"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: promos.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between rounded-2xl bg-surface px-3 py-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setPromo(p),
									className: "text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: p.code
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block text-muted",
										children: [
											p.type === "PERCENT" ? `${p.value}%` : baht(p.value),
											" · ขั้นต่ำ ",
											baht(p.minSpend),
											" · ",
											p.active ? "เปิด" : "ปิด"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => deletePromo(p.code),
									className: "min-h-11 px-3 text-danger",
									children: "ลบ"
								})]
							}, p.code))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								if (window.confirm("ล้างข้อมูลสาธิตทั้งหมด?")) {
									resetDemo();
									sessionStorage.removeItem("bai-khiao-admin");
									setUnlocked(false);
								}
							},
							className: "flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl bg-elevated text-sm text-danger",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), " รีเซ็ตข้อมูลสาธิต"]
						})
					]
				})]
			}) : null,
			tab === "deploy" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeployPanel, {}) : null,
			slip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 grid place-items-center bg-bg/80 p-4",
				onClick: () => setSlip(""),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: slip,
					alt: "สลิปโอนเงิน",
					className: "max-h-[80vh] max-w-full rounded-3xl"
				})
			}) : null
		]
	});
}
function settingsToForm(settings) {
	return {
		shopName: settings.shopName,
		shopPhone: settings.shopPhone,
		promptPayId: settings.promptPayId,
		shopLat: String(settings.shopLat),
		shopLng: String(settings.shopLng),
		feeBase: String(settings.feeBase),
		feePerKm: String(settings.feePerKm),
		pointsRate: String(settings.pointsRate),
		pointValue: String(settings.pointValue),
		lineChannelToken: settings.lineChannelToken,
		lineAdminUserId: settings.lineAdminUserId,
		adminPin: settings.adminPin
	};
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-3xl border border-line bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-2xl font-semibold text-primary",
			children: value
		})]
	});
}
function Field({ label, value, onChange, type = "text" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm text-muted",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type,
			value,
			onChange: (e) => onChange(e.target.value),
			className: "mt-1 min-h-11 w-full rounded-2xl border border-line bg-elevated px-3 text-base text-fg"
		})]
	});
}
function OrderList({ orders, onAct, onSlip, empty }) {
	if (!orders.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: empty
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-3",
		children: orders.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "rounded-3xl border border-line bg-surface p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: order.customerName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							order.orderId,
							" · ",
							formatWhen(order.timestamp)
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold text-primary",
							children: baht(order.total)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: STATUS_LABEL[order.status]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 text-sm text-muted",
					children: order.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						item.name,
						" × ",
						item.qty
					] }, item.productId))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm",
					children: order.fulfillment === "PICKUP" ? "รับที่ร้าน" : `${order.address} · ${order.distance.toFixed(2)} กม. · ส่ง ${baht(order.deliveryFee)}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						order.paymentMethod === "CASH" ? "เงินสด" : "โอนเงิน",
						order.discount ? ` · ส่วนลด ${baht(order.discount)}` : "",
						order.promoCode ? ` · ${order.promoCode}` : "",
						order.note ? ` · ${order.note}` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						order.status === "PENDING" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onAct(order.orderId, "DELIVERING"),
							className: "min-h-11 rounded-2xl bg-primary px-3 text-sm text-primary-fg",
							children: "รับออเดอร์"
						}) : null,
						order.status === "DELIVERING" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onAct(order.orderId, "COMPLETED"),
							className: "min-h-11 rounded-2xl bg-primary px-3 text-sm text-primary-fg",
							children: "ส่งสำเร็จ"
						}) : null,
						order.status === "PENDING" || order.status === "DELIVERING" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onAct(order.orderId, "CANCELLED"),
							className: "min-h-11 rounded-2xl bg-elevated px-3 text-sm text-danger",
							children: "ยกเลิก"
						}) : null,
						order.slipUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onSlip(order.slipUrl),
							className: "min-h-11 rounded-2xl bg-elevated px-3 text-sm",
							children: "ดูสลิป"
						}) : null,
						order.lat != null && order.lng != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "inline-flex min-h-11 items-center rounded-2xl bg-elevated px-3 text-sm",
							href: `https://maps.google.com/?q=${order.lat},${order.lng}`,
							target: "_blank",
							rel: "noreferrer",
							children: "แผนที่"
						}) : null
					]
				})
			]
		}, order.orderId))
	});
}
function DeployPanel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "max-w-3xl space-y-4 text-sm leading-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-3xl border border-line bg-surface p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "ไฟล์สำหรับ Google Apps Script + LINE LIFF"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "หน้าร้านที่ใช้อยู่เก็บข้อมูลในเบราว์เซอร์เพื่อทดลองทันที เมื่อจะเปิดร้านจริง ให้นำสามไฟล์นี้ไปวางใน Apps Script ระบบจะใช้ Google Sheets เป็นฐานข้อมูล ตัดสต๊อก บวกแต้ม และยิง LINE จริง"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "inline-flex min-h-11 items-center rounded-2xl bg-primary px-4 text-primary-fg",
							href: "/gas/Code.gs",
							download: true,
							children: "ดาวน์โหลด Code.gs"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "inline-flex min-h-11 items-center rounded-2xl bg-elevated px-4",
							href: "/gas/liff.html",
							download: true,
							children: "liff.html"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "inline-flex min-h-11 items-center rounded-2xl bg-elevated px-4",
							href: "/gas/admin.html",
							download: true,
							children: "admin.html"
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
			className: "list-decimal space-y-2 pl-5 text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "สร้าง Google Sheet ว่าง แล้วเปิด Extensions → Apps Script" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "วาง Code.gs ทับไฟล์เดิม สร้างไฟล์ HTML ชื่อ liff และ admin แล้ววางโค้ดให้ตรงชื่อ" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "เลือกฟังก์ชัน installSystem แล้วกดรัน อนุญาตสิทธิ์ Sheets, Drive และเชื่อมต่อภายนอก" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Deploy → New deployment → Web app, Execute as Me, Who has access: Anyone" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "ใส่ LIFF ID ใน liff.html และ Channel access token กับ User ID แอดมินในชีต Settings" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "ตั้ง Endpoint URL ของ LIFF เป็นลิงก์เว็บแอป (เปิดหน้าร้านอัตโนมัติ) ส่วนหลังบ้านต่อท้าย ?page=admin" })
			]
		})]
	});
}
function AdminPage() {
	if (!usePosReady()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminDesk, {});
}
//#endregion
export { AdminPage as component };
