/** สูตรคำนวณที่ใช้ร่วมกันทั้งหน้าร้านและหลังบ้าน — ต้องตรงกับ Code.gs */

export type PromoLike = {
  type: "PERCENT" | "FIXED";
  value: number;
  minSpend: number;
  active: boolean;
};

export function tlv(id: string, value: string) {
  return id + value.length.toString().padStart(2, "0") + value;
}

/** CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF) ตามสเปก EMVCo ของ PromptPay */
export function crc16Ccitt(payload: string) {
  let crc = 0xffff;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let bit = 0; bit < 8; bit++) {
      if (crc & 0x8000) crc = ((crc << 1) ^ 0x1021) & 0xffff;
      else crc = (crc << 1) & 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}

/** เบอร์มือถือ = tag 01 (เติม 0066 ให้ครบ 13), เลข 13 หลัก = tag 02, ยาวกว่า = tag 03 */
export function formatPromptPayTarget(raw: string): { type: "01" | "02" | "03"; value: string } {
  const id = String(raw || "").replace(/[^0-9]/g, "");
  if (id.length >= 15) return { type: "03", value: id };
  if (id.length >= 13) return { type: "02", value: id };
  const phone = ("0000000000000" + id.replace(/^0/, "66")).slice(-13);
  return { type: "01", value: phone };
}

/** Dynamic PromptPay QR (EMVCo) — ใส่ยอดเงินเมื่อ amount > 0 */
export function buildPromptPayPayload(promptPayId: string, amount: number) {
  const target = formatPromptPayTarget(promptPayId);
  const amt = Number(amount);
  const hasAmount = Number.isFinite(amt) && amt > 0;
  const merchant = tlv("00", "A000000677010111") + tlv(target.type, target.value);
  let body = "";
  body += tlv("00", "01");
  body += tlv("01", hasAmount ? "12" : "11");
  body += tlv("29", merchant);
  // ลำดับแท็กตามไลบรารี promptpay-qr ที่ธนาคารไทยสแกนได้จริง (58 ก่อน 53)
  body += tlv("58", "TH");
  body += tlv("53", "764");
  if (hasAmount) body += tlv("54", amt.toFixed(2));
  const withCrcMark = body + "6304";
  return withCrcMark + crc16Ccitt(withCrcMark);
}

/** ระยะทางกิโลเมตรระหว่างสองพิกัด (Haversine, รัศมีโลก 6371 กม.) */
export function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number) {
  const R = 6371;
  const rad = Math.PI / 180;
  const dLat = (lat2 - lat1) * rad;
  const dLng = (lng2 - lng1) * rad;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(Math.max(0, a))));
}

/** ค่าส่ง = ปัดขึ้น(ค่าเริ่มต้น + ระยะทางกม. × ค่าต่อกม.) */
export function deliveryFeeBaht(km: number, feeBase: number, feePerKm: number) {
  if (!Number.isFinite(km) || km < 0) return 0;
  return Math.max(0, Math.ceil(Number(feeBase) + km * Number(feePerKm)));
}

export function promoDiscount(subTotal: number, promo: PromoLike | null) {
  if (!promo || !promo.active) return 0;
  if (subTotal + 1e-9 < Number(promo.minSpend)) return 0;
  if (promo.type === "PERCENT") {
    return Math.min(subTotal, Math.floor((subTotal * Number(promo.value)) / 100));
  }
  return Math.min(subTotal, Math.round(Number(promo.value)));
}

export function quoteOrder(input: {
  subTotal: number;
  promo: PromoLike | null;
  pointsRequested: number;
  pointsBalance: number;
  pointValue: number;
  pointsRate: number;
  distanceKm: number;
  feeBase: number;
  feePerKm: number;
  fulfillment: "DELIVERY" | "PICKUP";
}) {
  const promoOff = promoDiscount(input.subTotal, input.promo);
  const afterPromo = Math.max(0, input.subTotal - promoOff);
  const pointValue = Math.max(0.01, Number(input.pointValue) || 1);
  const maxByMoney = Math.floor(afterPromo / pointValue);
  const pointsUsed = Math.max(
    0,
    Math.min(
      Math.floor(Number(input.pointsRequested) || 0),
      Math.floor(Number(input.pointsBalance) || 0),
      maxByMoney,
    ),
  );
  const pointsOff = Math.min(afterPromo, pointsUsed * pointValue);
  const discount = promoOff + pointsOff;
  const delivery =
    input.fulfillment === "PICKUP" ? 0 : deliveryFeeBaht(input.distanceKm, input.feeBase, input.feePerKm);
  const netGoods = Math.max(0, input.subTotal - discount);
  const rate = Number(input.pointsRate) || 0;
  const pointsEarned = rate > 0 ? Math.floor(netGoods / rate) : 0;
  const total = netGoods + delivery;
  return { promoOff, pointsUsed, pointsOff, discount, delivery, pointsEarned, total, netGoods };
}

export function baht(n: number) {
  return new Intl.NumberFormat("th-TH", {
    style: "currency",
    currency: "THB",
    maximumFractionDigits: 0,
  }).format(Math.round(Number(n) || 0));
}

export function todayBangkok(iso?: string) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Bangkok",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(iso ? new Date(iso) : new Date());
}

export function formatWhen(iso: string) {
  return new Intl.DateTimeFormat("th-TH", {
    timeZone: "Asia/Bangkok",
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(iso));
}
