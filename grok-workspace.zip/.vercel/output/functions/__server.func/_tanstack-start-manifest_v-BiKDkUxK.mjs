//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BiKDkUxK.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/admin"],
		preloads: ["/assets/index-CrmuvQX-.js", "/assets/rolldown-runtime-hePW80VL.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CrmuvQX-.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BBJxZiN7.js", "/assets/ready-BmfgrftR.js"]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: ["/assets/admin-D_Nb2n8e.js", "/assets/ready-BmfgrftR.js"]
	}
} });
//#endregion
export { tsrStartManifest };
