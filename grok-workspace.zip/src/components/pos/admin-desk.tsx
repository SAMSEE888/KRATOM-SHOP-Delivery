import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Leaf, RotateCcw } from "lucide-react";
import { baht, formatWhen, todayBangkok } from "@/lib/pos/calc";
import { usePos } from "@/lib/pos/store";
import { RECIPE_TYPES, STATUS_LABEL, type OrderStatus, type Product, type Promo, type Settings } from "@/lib/pos/types";

const TABS = [
  ["home", "ภาพรวม"],
  ["orders", "ออเดอร์"],
  ["products", "สินค้า"],
  ["customers", "ลูกค้า"],
  ["settings", "ตั้งค่า"],
  ["deploy", "ขึ้นระบบ"],
] as const;

type Tab = (typeof TABS)[number][0];

function blankProduct(): Product {
  return {
    id: "P" + Date.now().toString(36).toUpperCase(),
    name: "",
    price: 0,
    recipeType: "ใบแห้ง",
    status: "ACTIVE",
    imageUrl: "",
    stock: 0,
  };
}

export function AdminDesk() {
  const settings = usePos((s) => s.settings);
  const orders = usePos((s) => s.orders);
  const products = usePos((s) => s.products);
  const customers = usePos((s) => s.customers);
  const promos = usePos((s) => s.promos);
  const stockLogs = usePos((s) => s.stockLogs);
  const updateOrderStatus = usePos((s) => s.updateOrderStatus);
  const saveProduct = usePos((s) => s.saveProduct);
  const deleteProduct = usePos((s) => s.deleteProduct);
  const adjustStock = usePos((s) => s.adjustStock);
  const saveSettings = usePos((s) => s.saveSettings);
  const savePromo = usePos((s) => s.savePromo);
  const deletePromo = usePos((s) => s.deletePromo);
  const adjustPoints = usePos((s) => s.adjustPoints);
  const resetDemo = usePos((s) => s.resetDemo);

  const [tab, setTab] = useState<Tab>("home");
  const [unlocked, setUnlocked] = useState(false);
  const [pin, setPin] = useState("");
  const [pinError, setPinError] = useState("");
  const [status, setStatus] = useState<"ALL" | OrderStatus>("ALL");
  const [query, setQuery] = useState("");
  const [slip, setSlip] = useState("");
  const [creating, setCreating] = useState(true);
  const [draft, setDraft] = useState<Product>(blankProduct);
  const [stockTarget, setStockTarget] = useState("");
  const [initialStock, setInitialStock] = useState("0");
  const [stockQty, setStockQty] = useState(1);
  const [stockNote, setStockNote] = useState("");
  const [form, setForm] = useState(() => settingsToForm(settings));
  const [formError, setFormError] = useState("");
  const [promo, setPromo] = useState<Promo>({ code: "", type: "PERCENT", value: 10, minSpend: 0, active: true });
  const [notice, setNotice] = useState("");

  useEffect(() => {
    if (sessionStorage.getItem("bai-khiao-admin") === "1") setUnlocked(true);
  }, []);

  const today = todayBangkok();
  const liveOrders = orders.filter((o) => o.status !== "CANCELLED");
  const todaySales = liveOrders.filter((o) => todayBangkok(o.timestamp) === today).reduce((sum, o) => sum + o.total, 0);
  const pending = orders.filter((o) => o.status === "PENDING").length;
  const delivering = orders.filter((o) => o.status === "DELIVERING").length;
  const chart = useMemo(() => {
    const rows: { day: string; total: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date(Date.now() - i * 86400000);
      const key = todayBangkok(date.toISOString());
      const label = new Intl.DateTimeFormat("th-TH", { timeZone: "Asia/Bangkok", day: "numeric", month: "short" }).format(date);
      const total = orders
        .filter((o) => o.status !== "CANCELLED" && todayBangkok(o.timestamp) === key)
        .reduce((sum, o) => sum + o.total, 0);
      rows.push({ day: label, total });
    }
    return rows;
  }, [orders]);

  const filtered = orders.filter((o) => {
    if (status !== "ALL" && o.status !== status) return false;
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return o.orderId.toLowerCase().includes(q) || o.customerName.toLowerCase().includes(q) || o.address.toLowerCase().includes(q);
  });

  function unlock() {
    if (pin.trim() === settings.adminPin) {
      sessionStorage.setItem("bai-khiao-admin", "1");
      setUnlocked(true);
      setPinError("");
      return;
    }
    setPinError("รหัสไม่ถูกต้อง");
  }

  function act(orderId: string, next: OrderStatus) {
    const error = updateOrderStatus(orderId, next);
    setNotice(error || `อัปเดต ${orderId} เป็น ${STATUS_LABEL[next]}`);
  }

  function saveDraft() {
    if (!draft.name.trim()) {
      setNotice("ใส่ชื่อสินค้า");
      return;
    }
    saveProduct({ ...draft, name: draft.name.trim(), price: Number(draft.price) || 0 }, creating ? Number(initialStock) || 0 : undefined);
    setNotice("บันทึกสินค้าแล้ว");
    setCreating(false);
  }

  function onSaveSettings() {
    if (!form.shopName.trim()) {
      setFormError("ใส่ชื่อร้าน");
      return;
    }
    const shopLat = Number(form.shopLat);
    const shopLng = Number(form.shopLng);
    if (!Number.isFinite(shopLat) || !Number.isFinite(shopLng)) {
      setFormError("พิกัดร้านไม่ถูกต้อง");
      return;
    }
    if (Number(form.pointsRate) < 1 || Number(form.pointValue) <= 0) {
      setFormError("อัตราแต้มต้องมากกว่า 0");
      return;
    }
    saveSettings({
      shopName: form.shopName.trim(),
      shopPhone: form.shopPhone.trim(),
      promptPayId: form.promptPayId.replace(/\s/g, ""),
      shopLat,
      shopLng,
      feeBase: Math.max(0, Number(form.feeBase) || 0),
      feePerKm: Math.max(0, Number(form.feePerKm) || 0),
      pointsRate: Math.max(1, Number(form.pointsRate) || 1),
      pointValue: Math.max(0.01, Number(form.pointValue) || 1),
      lineChannelToken: form.lineChannelToken.trim(),
      lineAdminUserId: form.lineAdminUserId.trim(),
      adminPin: form.adminPin.trim() || "2580",
    });
    setFormError("");
    setNotice("บันทึกการตั้งค่าแล้ว");
  }

  if (!unlocked) {
    return (
      <main className="grid min-h-screen place-items-center px-5">
        <section className="glass w-full max-w-sm rounded-3xl p-6">
          <div className="mb-4 grid size-12 place-items-center rounded-2xl bg-primary text-primary-fg">
            <Leaf className="size-6" />
          </div>
          <h1 className="text-2xl font-semibold">หลังบ้านใบเขียว</h1>
          <p className="mt-2 text-sm text-muted">รหัสเริ่มต้น 2580 เปลี่ยนได้ในตั้งค่า</p>
          <input value={pin} onChange={(e) => setPin(e.target.value)} type="password" inputMode="numeric" aria-label="รหัสแอดมิน" className="mt-4 min-h-11 w-full rounded-2xl border border-line bg-elevated px-3 text-base" />
          {pinError ? <p className="mt-2 text-sm text-danger" role="alert">{pinError}</p> : null}
          <button type="button" onClick={unlock} className="mt-4 min-h-11 w-full rounded-2xl bg-primary font-medium text-primary-fg">เข้าสู่ระบบ</button>
          <Link to="/" className="mt-3 block text-center text-sm text-muted">กลับหน้าร้าน</Link>
        </section>
      </main>
    );
  }

  return (
    <div className="mx-auto min-h-screen max-w-6xl px-4 pb-16 pt-4">
      <header className="mb-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="grid size-11 place-items-center rounded-2xl bg-primary text-primary-fg"><Leaf className="size-5" /></div>
          <div>
            <h1 className="text-xl font-semibold">{settings.shopName}</h1>
            <p className="text-sm text-muted">หลังบ้าน · ข้อมูลอยู่บนเครื่องนี้</p>
          </div>
        </div>
        <Link to="/" className="min-h-11 rounded-2xl bg-elevated px-4 py-2 text-sm">หน้าร้าน</Link>
      </header>
      <nav className="no-scrollbar -mx-4 mb-4 flex gap-2 overflow-x-auto px-4">
        {TABS.map(([id, label]) => (
          <button key={id} type="button" onClick={() => setTab(id)} className={`min-h-11 shrink-0 rounded-full px-4 text-sm ${tab === id ? "bg-primary text-primary-fg" : "bg-elevated text-muted"}`}>
            {label}
          </button>
        ))}
      </nav>
      {notice ? <p className="mb-3 rounded-2xl bg-elevated px-4 py-3 text-sm" role="status">{notice}</p> : null}

      {tab === "home" ? (
        <section className="space-y-4">
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Stat label="ยอดขายวันนี้" value={baht(todaySales)} />
            <Stat label="รอดำเนินการ" value={String(pending)} />
            <Stat label="กำลังส่ง" value={String(delivering)} />
            <Stat label="ออเดอร์ทั้งหมด" value={String(orders.length)} />
          </div>
          <div className="rounded-3xl border border-line bg-surface p-4">
            <h2 className="mb-3 text-sm text-muted">ยอดขาย 7 วัน (ไม่รวมที่ยกเลิก)</h2>
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chart}>
                  <XAxis dataKey="day" stroke="var(--color-muted)" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="var(--color-muted)" fontSize={12} tickLine={false} axisLine={false} width={40} />
                  <Tooltip
                    formatter={(value) => baht(Number(value))}
                    contentStyle={{ background: "var(--color-elevated)", border: "1px solid var(--color-line)", borderRadius: 12, color: "var(--color-fg)" }}
                  />
                  <Area type="monotone" dataKey="total" stroke="var(--color-primary)" fill="var(--color-primary)" fillOpacity={0.2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
          <OrderList orders={orders.filter((o) => o.status === "PENDING" || o.status === "DELIVERING")} onAct={act} onSlip={setSlip} empty="ไม่มีออเดอร์ค้าง" />
        </section>
      ) : null}

      {tab === "orders" ? (
        <section>
          <div className="mb-3 flex flex-col gap-2 sm:flex-row">
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="ค้นหาเลขที่ / ชื่อ / ที่อยู่" className="min-h-11 flex-1 rounded-2xl border border-line bg-surface px-3 text-base" />
            <select value={status} onChange={(e) => setStatus(e.target.value as "ALL" | OrderStatus)} className="min-h-11 rounded-2xl border border-line bg-surface px-3 text-base">
              <option value="ALL">ทุกสถานะ</option>
              {(Object.keys(STATUS_LABEL) as OrderStatus[]).map((key) => (
                <option key={key} value={key}>{STATUS_LABEL[key]}</option>
              ))}
            </select>
          </div>
          <OrderList orders={filtered} onAct={act} onSlip={setSlip} empty="ไม่พบออเดอร์" />
        </section>
      ) : null}

      {tab === "products" ? (
        <section className="grid gap-4 lg:grid-cols-[1fr_1.2fr]">
          <form className="space-y-3 rounded-3xl border border-line bg-surface p-4" onSubmit={(e) => { e.preventDefault(); saveDraft(); }}>
            <h2 className="font-medium">{creating || !products.some((p) => p.id === draft.id) ? "สินค้าใหม่" : "แก้ไขสินค้า"}</h2>
            <Field label="ชื่อ" value={draft.name} onChange={(v) => setDraft({ ...draft, name: v })} />
            <Field label="ราคา" value={String(draft.price)} onChange={(v) => setDraft({ ...draft, price: Number(v) })} type="number" />
            <label className="block text-sm text-muted">ประเภท
              <select value={draft.recipeType} onChange={(e) => setDraft({ ...draft, recipeType: e.target.value })} className="mt-1 min-h-11 w-full rounded-2xl border border-line bg-elevated px-3 text-base">
                {RECIPE_TYPES.map((t) => <option key={t}>{t}</option>)}
              </select>
            </label>
            <label className="block text-sm text-muted">สถานะ
              <select value={draft.status} onChange={(e) => setDraft({ ...draft, status: e.target.value as Product["status"] })} className="mt-1 min-h-11 w-full rounded-2xl border border-line bg-elevated px-3 text-base">
                <option value="ACTIVE">เปิดขาย</option>
                <option value="INACTIVE">ปิดขาย</option>
              </select>
            </label>
            <Field label="ลิงก์รูป" value={draft.imageUrl} onChange={(v) => setDraft({ ...draft, imageUrl: v })} />
            {creating ? <Field label="สต๊อกเริ่มต้น" value={initialStock} onChange={setInitialStock} type="number" /> : <p className="text-sm text-muted">สต๊อกปัจจุบัน {products.find((p) => p.id === draft.id)?.stock ?? 0} — ปรับแยกด้านขวา</p>}
            <div className="flex gap-2">
              <button type="submit" className="min-h-11 flex-1 rounded-2xl bg-primary font-medium text-primary-fg">บันทึก</button>
              <button type="button" onClick={() => { setCreating(true); setDraft(blankProduct()); setInitialStock("0"); }} className="min-h-11 rounded-2xl bg-elevated px-4 text-sm">ใหม่</button>
            </div>
          </form>
          <ul className="space-y-2">
            {products.map((p) => (
              <li key={p.id} className="rounded-3xl border border-line bg-surface p-3">
                <button type="button" onClick={() => { setCreating(false); setDraft(p); }} className="flex w-full items-center gap-3 text-left">
                  <div className="size-14 overflow-hidden rounded-2xl bg-elevated">
                    {p.imageUrl ? <img src={p.imageUrl} alt="" className="h-full w-full object-cover" /> : null}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{p.name}</p>
                    <p className="text-sm text-muted">{baht(p.price)} · เหลือ {p.stock} · {p.status === "ACTIVE" ? "เปิดขาย" : "ปิดขาย"}</p>
                  </div>
                </button>
                <div className="mt-2 flex flex-wrap gap-2">
                  <button type="button" onClick={() => { setStockNote(""); setStockQty(1); setStockTarget(stockTarget === p.id ? "" : p.id); }} className="min-h-11 rounded-2xl bg-elevated px-3 text-sm">ปรับสต๊อก</button>
                  <button type="button" onClick={() => deleteProduct(p.id)} className="min-h-11 rounded-2xl px-3 text-sm text-danger">ลบ</button>
                </div>
                {stockTarget === p.id ? (
                  <div className="mt-2 flex flex-wrap gap-2">
                    <input type="number" min={1} value={stockQty} onChange={(e) => setStockQty(Number(e.target.value))} aria-label="จำนวน" className="min-h-11 w-24 rounded-2xl border border-line bg-elevated px-3" />
                    <input value={stockNote} onChange={(e) => setStockNote(e.target.value)} placeholder="โน้ต" className="min-h-11 min-w-32 flex-1 rounded-2xl border border-line bg-elevated px-3" />
                    <button type="button" onClick={() => setNotice(adjustStock(p.id, "IN", stockQty, stockNote) || "รับเข้าแล้ว")} className="min-h-11 rounded-2xl bg-primary px-3 text-sm text-primary-fg">เข้า</button>
                    <button type="button" onClick={() => setNotice(adjustStock(p.id, "OUT", stockQty, stockNote) || "ตัดออกแล้ว")} className="min-h-11 rounded-2xl bg-elevated px-3 text-sm">ออก</button>
                  </div>
                ) : null}
              </li>
            ))}
          </ul>
          <div className="lg:col-span-2">
            <h2 className="mb-2 text-sm text-muted">ความเคลื่อนไหวสต๊อกล่าสุด</h2>
            <ul className="space-y-1 text-sm">
              {stockLogs.slice(0, 12).map((log) => (
                <li key={log.id} className="flex justify-between gap-3 rounded-2xl bg-surface px-3 py-2">
                  <span>{log.type === "IN" ? "เข้า" : "ออก"} {log.productName} {log.qty} · คงเหลือ {log.balance}</span>
                  <span className="text-muted">{log.note}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>
      ) : null}

      {tab === "customers" ? (
        <section className="space-y-2">
          {customers.length === 0 ? <p className="text-sm text-muted">ยังไม่มีลูกค้า — จะถูกสร้างเมื่อมีการสั่งซื้อ</p> : null}
          {customers.map((c) => (
            <article key={c.lineUserId} className="rounded-3xl border border-line bg-surface p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="font-medium">{c.name}</h2>
                  <p className="text-xs text-muted">{c.lineUserId}</p>
                </div>
                <p className="text-primary">{c.points} แต้ม</p>
              </div>
              <p className="mt-2 text-sm text-muted">ยอดสะสม {baht(c.totalSpent)} · ล่าสุด {c.lastOrderDate ? formatWhen(c.lastOrderDate) : "-"}</p>
              <div className="mt-3 flex gap-2">
                <button type="button" onClick={() => adjustPoints(c.lineUserId, 10)} className="min-h-11 rounded-2xl bg-elevated px-3 text-sm">+10 แต้ม</button>
                <button type="button" onClick={() => adjustPoints(c.lineUserId, -10)} className="min-h-11 rounded-2xl bg-elevated px-3 text-sm">-10 แต้ม</button>
              </div>
            </article>
          ))}
        </section>
      ) : null}

      {tab === "settings" ? (
        <section className="grid gap-4 lg:grid-cols-2">
          <form className="space-y-3 rounded-3xl border border-line bg-surface p-4" onSubmit={(e) => { e.preventDefault(); onSaveSettings(); }}>
            <Field label="ชื่อร้าน" value={form.shopName} onChange={(v) => setForm({ ...form, shopName: v })} />
            <Field label="เบอร์โทร" value={form.shopPhone} onChange={(v) => setForm({ ...form, shopPhone: v })} />
            <Field label="พร้อมเพย์ (เบอร์หรือเลขผู้เสียภาษี)" value={form.promptPayId} onChange={(v) => setForm({ ...form, promptPayId: v })} />
            <div className="grid grid-cols-2 gap-2">
              <Field label="ละติจูดร้าน" value={form.shopLat} onChange={(v) => setForm({ ...form, shopLat: v })} />
              <Field label="ลองจิจูดร้าน" value={form.shopLng} onChange={(v) => setForm({ ...form, shopLng: v })} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Field label="ค่าส่งเริ่มต้น (บาท)" value={form.feeBase} onChange={(v) => setForm({ ...form, feeBase: v })} />
              <Field label="ค่าส่งต่อกิโลเมตร" value={form.feePerKm} onChange={(v) => setForm({ ...form, feePerKm: v })} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Field label="บาทต่อการได้ 1 แต้ม" value={form.pointsRate} onChange={(v) => setForm({ ...form, pointsRate: v })} />
              <Field label="บาทที่ลดได้ต่อ 1 แต้ม" value={form.pointValue} onChange={(v) => setForm({ ...form, pointValue: v })} />
            </div>
            <Field label="Channel access token (LINE)" value={form.lineChannelToken} onChange={(v) => setForm({ ...form, lineChannelToken: v })} />
            <Field label="User ID แอดมิน (รับแจ้งเตือน)" value={form.lineAdminUserId} onChange={(v) => setForm({ ...form, lineAdminUserId: v })} />
            <Field label="รหัสหลังบ้าน" value={form.adminPin} onChange={(v) => setForm({ ...form, adminPin: v })} />
            <p className="text-xs leading-5 text-muted">ค่าส่ง = ปัดขึ้น(ค่าเริ่มต้น + ระยะทางกม. × ค่าต่อกม.) โทเคน LINE ใช้เมื่อต่อ Apps Script จริง</p>
            {formError ? <p className="text-sm text-danger">{formError}</p> : null}
            <button type="submit" className="min-h-11 w-full rounded-2xl bg-primary font-medium text-primary-fg">บันทึกการตั้งค่า</button>
          </form>
          <div className="space-y-3">
            <form className="space-y-3 rounded-3xl border border-line bg-surface p-4" onSubmit={(e) => { e.preventDefault(); if (!promo.code.trim()) return; savePromo(promo); setNotice("บันทึกโปรโมชันแล้ว"); }}>
              <h2 className="font-medium">โปรโมชัน</h2>
              <Field label="โค้ด" value={promo.code} onChange={(v) => setPromo({ ...promo, code: v.toUpperCase() })} />
              <label className="block text-sm text-muted">ชนิด
                <select value={promo.type} onChange={(e) => setPromo({ ...promo, type: e.target.value as Promo["type"] })} className="mt-1 min-h-11 w-full rounded-2xl border border-line bg-elevated px-3">
                  <option value="PERCENT">เปอร์เซ็นต์</option>
                  <option value="FIXED">บาท</option>
                </select>
              </label>
              <div className="grid grid-cols-2 gap-2">
                <Field label="มูลค่า" value={String(promo.value)} onChange={(v) => setPromo({ ...promo, value: Number(v) })} type="number" />
                <Field label="ยอดขั้นต่ำ" value={String(promo.minSpend)} onChange={(v) => setPromo({ ...promo, minSpend: Number(v) })} type="number" />
              </div>
              <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" checked={promo.active} onChange={(e) => setPromo({ ...promo, active: e.target.checked })} /> เปิดใช้</label>
              <button type="submit" className="min-h-11 w-full rounded-2xl bg-primary font-medium text-primary-fg">บันทึกโค้ด</button>
            </form>
            <ul className="space-y-2">
              {promos.map((p) => (
                <li key={p.code} className="flex items-center justify-between rounded-2xl bg-surface px-3 py-2 text-sm">
                  <button type="button" onClick={() => setPromo(p)} className="text-left">
                    <span className="font-medium">{p.code}</span>
                    <span className="block text-muted">{p.type === "PERCENT" ? `${p.value}%` : baht(p.value)} · ขั้นต่ำ {baht(p.minSpend)} · {p.active ? "เปิด" : "ปิด"}</span>
                  </button>
                  <button type="button" onClick={() => deletePromo(p.code)} className="min-h-11 px-3 text-danger">ลบ</button>
                </li>
              ))}
            </ul>
            <button type="button" onClick={() => { if (window.confirm("ล้างข้อมูลสาธิตทั้งหมด?")) { resetDemo(); sessionStorage.removeItem("bai-khiao-admin"); setUnlocked(false); } }} className="flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl bg-elevated text-sm text-danger">
              <RotateCcw className="size-4" /> รีเซ็ตข้อมูลสาธิต
            </button>
          </div>
        </section>
      ) : null}

      {tab === "deploy" ? <DeployPanel /> : null}

      {slip ? (
        <div className="fixed inset-0 z-40 grid place-items-center bg-bg/80 p-4" onClick={() => setSlip("")}>
          <img src={slip} alt="สลิปโอนเงิน" className="max-h-[80vh] max-w-full rounded-3xl" />
        </div>
      ) : null}
    </div>
  );
}

function settingsToForm(settings: Settings) {
  return {
    shopName: settings.shopName,
    shopPhone: settings.shopPhone,
    promptPayId: settings.promptPayId,
    shopLat: String(settings.shopLat),
    shopLng: String(settings.shopLng),
    feeBase: String(settings.feeBase),
    feePerKm: String(settings.feePerKm),
    pointsRate: String(settings.pointsRate),
    pointValue: String(settings.pointValue),
    lineChannelToken: settings.lineChannelToken,
    lineAdminUserId: settings.lineAdminUserId,
    adminPin: settings.adminPin,
  };
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <article className="rounded-3xl border border-line bg-surface p-4">
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-1 text-2xl font-semibold text-primary">{value}</p>
    </article>
  );
}

function Field({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <label className="block text-sm text-muted">{label}
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} className="mt-1 min-h-11 w-full rounded-2xl border border-line bg-elevated px-3 text-base text-fg" />
    </label>
  );
}

function OrderList({
  orders,
  onAct,
  onSlip,
  empty,
}: {
  orders: ReturnType<typeof usePos.getState>["orders"];
  onAct: (id: string, status: OrderStatus) => void;
  onSlip: (url: string) => void;
  empty: string;
}) {
  if (!orders.length) return <p className="text-sm text-muted">{empty}</p>;
  return (
    <ul className="space-y-3">
      {orders.map((order) => (
        <li key={order.orderId} className="rounded-3xl border border-line bg-surface p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="font-medium">{order.customerName}</p>
              <p className="text-xs text-muted">{order.orderId} · {formatWhen(order.timestamp)}</p>
            </div>
            <div className="text-right">
              <p className="font-semibold text-primary">{baht(order.total)}</p>
              <p className="text-xs text-muted">{STATUS_LABEL[order.status]}</p>
            </div>
          </div>
          <ul className="mt-2 text-sm text-muted">
            {order.items.map((item) => (
              <li key={item.productId}>{item.name} × {item.qty}</li>
            ))}
          </ul>
          <p className="mt-2 text-sm">
            {order.fulfillment === "PICKUP" ? "รับที่ร้าน" : `${order.address} · ${order.distance.toFixed(2)} กม. · ส่ง ${baht(order.deliveryFee)}`}
          </p>
          <p className="text-sm text-muted">
            {order.paymentMethod === "CASH" ? "เงินสด" : "โอนเงิน"}
            {order.discount ? ` · ส่วนลด ${baht(order.discount)}` : ""}
            {order.promoCode ? ` · ${order.promoCode}` : ""}
            {order.note ? ` · ${order.note}` : ""}
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            {order.status === "PENDING" ? <button type="button" onClick={() => onAct(order.orderId, "DELIVERING")} className="min-h-11 rounded-2xl bg-primary px-3 text-sm text-primary-fg">รับออเดอร์</button> : null}
            {order.status === "DELIVERING" ? <button type="button" onClick={() => onAct(order.orderId, "COMPLETED")} className="min-h-11 rounded-2xl bg-primary px-3 text-sm text-primary-fg">ส่งสำเร็จ</button> : null}
            {order.status === "PENDING" || order.status === "DELIVERING" ? (
              <button type="button" onClick={() => onAct(order.orderId, "CANCELLED")} className="min-h-11 rounded-2xl bg-elevated px-3 text-sm text-danger">ยกเลิก</button>
            ) : null}
            {order.slipUrl ? <button type="button" onClick={() => onSlip(order.slipUrl)} className="min-h-11 rounded-2xl bg-elevated px-3 text-sm">ดูสลิป</button> : null}
            {order.lat != null && order.lng != null ? (
              <a className="inline-flex min-h-11 items-center rounded-2xl bg-elevated px-3 text-sm" href={`https://maps.google.com/?q=${order.lat},${order.lng}`} target="_blank" rel="noreferrer">แผนที่</a>
            ) : null}
          </div>
        </li>
      ))}
    </ul>
  );
}

function DeployPanel() {
  return (
    <section className="max-w-3xl space-y-4 text-sm leading-6">
      <div className="rounded-3xl border border-line bg-surface p-4">
        <h2 className="text-lg font-semibold">ไฟล์สำหรับ Google Apps Script + LINE LIFF</h2>
        <p className="mt-2 text-muted">หน้าร้านที่ใช้อยู่เก็บข้อมูลในเบราว์เซอร์เพื่อทดลองทันที เมื่อจะเปิดร้านจริง ให้นำสามไฟล์นี้ไปวางใน Apps Script ระบบจะใช้ Google Sheets เป็นฐานข้อมูล ตัดสต๊อก บวกแต้ม และยิง LINE จริง</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <a className="inline-flex min-h-11 items-center rounded-2xl bg-primary px-4 text-primary-fg" href="/gas/Code.gs" download>ดาวน์โหลด Code.gs</a>
          <a className="inline-flex min-h-11 items-center rounded-2xl bg-elevated px-4" href="/gas/liff.html" download>liff.html</a>
          <a className="inline-flex min-h-11 items-center rounded-2xl bg-elevated px-4" href="/gas/admin.html" download>admin.html</a>
        </div>
      </div>
      <ol className="list-decimal space-y-2 pl-5 text-muted">
        <li>สร้าง Google Sheet ว่าง แล้วเปิด Extensions → Apps Script</li>
        <li>วาง Code.gs ทับไฟล์เดิม สร้างไฟล์ HTML ชื่อ liff และ admin แล้ววางโค้ดให้ตรงชื่อ</li>
        <li>เลือกฟังก์ชัน installSystem แล้วกดรัน อนุญาตสิทธิ์ Sheets, Drive และเชื่อมต่อภายนอก</li>
        <li>Deploy → New deployment → Web app, Execute as Me, Who has access: Anyone</li>
        <li>ใส่ LIFF ID ใน liff.html และ Channel access token กับ User ID แอดมินในชีต Settings</li>
        <li>ตั้ง Endpoint URL ของ LIFF เป็นลิงก์เว็บแอป (เปิดหน้าร้านอัตโนมัติ) ส่วนหลังบ้านต่อท้าย ?page=admin</li>
      </ol>
    </section>
  );
}
